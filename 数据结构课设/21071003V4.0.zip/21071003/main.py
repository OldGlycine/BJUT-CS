# -*- coding: utf-8 -*-

# import 核心部件
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import PyQt5.QtGui
import Ui_main

# import 辅助部件
import math
import pandas as pd

# 导入其他工程文件
from interact import * # 导入组件交互


app = QtWidgets.QApplication(sys.argv)
MainWindow = QtWidgets.QMainWindow()

ui = Ui_main.Ui_OldGao_21071003()
ui.setupUi(MainWindow)

if __name__ == '__main__':
    
    ui.actionSaveOption.setEnabled(False)

    # 生成方案按钮
    ui.button_generate.setCheckable(False)
    ui.button_generate.clicked.connect(lambda:schemeGenerate(ui.textBrowser, bar=ui.progressBar, md=ui.total_table, ac=[ui.actionSaveOption, ui.delete_box, ui.delete_over, ui.add_box_id, ui.textEdit, ui.creditbox, ui.hourbox, ui.add_over, ui.draw]))

    # 表格栏
        # 设置可拖动查看
    ui.total_table.horizontalHeader().setSectionsMovable(True)
    ui.total_table.verticalHeader().setSectionsMovable(True)
        # 启动拖动互换
    # ui.total_table.setDragEnabled(True)
    # ui.total_table.setAcceptDrops(True)
    # ui.total_table.setDropIndicatorShown(True)
    # ui.total_table.setMouseTracking(True)
    # ui.total_table.horizontalHeader().setDragEnabled(False)
    # ui.total_table.verticalHeader().setDragEnabled(False)
        # 拖动模式
    # ui.total_table.horizontalHeader().setDragDropMode(QtWidgets.QAbstractItemView.)
    # ui.total_table.verticalHeader().setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
    # ui.total_table.dragDropMode()
    # ui.total_table.setDefaultDropAction(QtCore.Qt.DropAction.MoveAction)
    # ui.total_table.dragEnterEvent(QtGui.)
    # ui.total_table.setDragDropMode(QtWidgets.QAbstractItemView.DragDropMode.DragDrop)
        # 一个单元格内容很长时，设置表头来显示完整单元格
    ui.total_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
    ui.total_table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        # 设置单元格选中模式
    # ui.total_table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
    # ui.total_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectItems)
    
    # 开始初始化表格
        # 绑定数据
    ui.total_table.setModel(interact.model)

    ui.progressBar.setRange(0, 100)
    
    ui.freeze.clicked.connect(lambda:activate([ui.button_generate, ui.box_hour_per_term, ui.add_over, ui.add_box_id, ui.textEdit, ui.creditbox, ui.hourbox, ui.add_over], [ui.delete_box, ui.delete_over, ui.exchange_over, ui.cb_exchange_term, ui.exchange_box]))

    ui.box_hour_per_term.valueChanged.connect(lambda:setHour(ui.box_hour_per_term, ui.textBrowser))
    # 目前差：保存读取课表,需要保存model，graph(Graph文件保存下来即可),sems(同样是sems文件保存下来即可)
    # 需要注意的是读取后按钮freeze状态（建议此时只能删课或者换课，注意tb的问题姿势），以及interact能正确读取(全局变量，头疼)

    ui.delete_over.clicked.connect(lambda:deleteClass(ui.textBrowser, ui.total_table, ui.delete_box))

    ui.add_over.clicked.connect(lambda:addCourse(ui.textBrowser, ui.total_table, ui.textEdit, ui.creditbox, ui.hourbox, ui.add_box_id, ui.progressBar))

    ui.exchange_over.clicked.connect(lambda:exchangeCourse(ui.textBrowser, ui.total_table, ui.exchange_box, ui.cb_exchange_term))

    ui.draw.clicked.connect(lambda:draw(ui.textBrowser))

    ui.actionSaveOption.triggered.connect(lambda:optionSave(ui.textBrowser, ui.total_table))

    ui.actionOpenOption.triggered.connect(lambda:optionLoad(ui.textBrowser, ui.total_table,
                                                              [ui.button_generate, ui.box_hour_per_term, ui.add_over, ui.add_box_id, ui.textEdit, ui.creditbox, ui.hourbox, ui.add_over],
                                                              [ui.actionSaveOption, ui.delete_box, ui.delete_over, ui.exchange_over, ui.cb_exchange_term, ui.exchange_box, ui.draw]))

    MainWindow.show()
    sys.exit(app.exec_())