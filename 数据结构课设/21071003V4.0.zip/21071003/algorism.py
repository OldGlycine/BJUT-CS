# 算法文件
import pandas as pd
import classes
import random
import numpy as np
from PyQt5 import QtWidgets

import interact
import main
import copy

total_len = 0

# 首先是输入数据的读取
def load_data():
    data = pd.read_csv('courses.csv')
    # TODO
    return data

# 然后是建图
# 建图需要:index, 课程名字，学分，学时，开设时间限制
def init_graph(data):
    courses_list = []
    global total_len
    total_len = len(data)
    for i in range(len(data)):
        courses_list.append(classes.courses(
            id=data['id'][i].astype(int),
              name=data['课程名称'][i],
              credit=data['学分'][i].astype(float),
              hour=data['学时'][i].astype(int),
              limit=data['开设时间限制'][i].astype(bool)))
    g = classes.Graph(len(courses_list))
    interact.courses_list = courses_list
    # from, to, to.weight

    addV = []
    file = open('Graph_ori', 'r')
    gstr = file.read()
    for ss in gstr.split('\n')[:-1]:
        if len(ss.split(',')) == 1:
            addV.append(int(ss))
        else:
            num1 = int(ss.split(',')[0])
            num2 = int(ss.split(',')[1])
            g.setEdge(courses_list[num1], courses_list[num2], courses_list[num2].Ccredit)

    g.sortG()

    for nums in addV:
        g.addVertex(courses_list[nums])

    interact.g = copy.deepcopy(g)

    file.close()


    # 重新覆盖Graph
    file = open('Graph_ori', 'r')
    togstr = file.read()
    file.close()

    file = open('Graph', 'w')
    file.write(togstr)
    file.close()
    

    # # 文科分支
    # g.setEdge(courses_list[0], courses_list[6], courses_list[6].Ccredit)
    # g.setEdge(courses_list[0], courses_list[10], courses_list[10].Ccredit)
    # g.setEdge(courses_list[6], courses_list[12], courses_list[12].Ccredit)
    # g.setEdge(courses_list[10], courses_list[12], courses_list[12].Ccredit)
    # g.setEdge(courses_list[12], courses_list[16], courses_list[16].Ccredit)

    # # 体育分支
    # g.setEdge(courses_list[1], courses_list[7], courses_list[7].Ccredit)
    # g.setEdge(courses_list[7], courses_list[13], courses_list[13].Ccredit)
    # g.setEdge(courses_list[13], courses_list[15], courses_list[15].Ccredit)

    # # 形势政策分支
    # g.setEdge(courses_list[64], courses_list[65], courses_list[65].Ccredit)

    # # 物理实验分支
    # g.setEdge(courses_list[33], courses_list[35], courses_list[35].Ccredit)
    # g.setEdge(courses_list[33], courses_list[34], courses_list[34].Ccredit)

    # # 大学英语分支
    # g.setEdge(courses_list[2], courses_list[8], courses_list[8].Ccredit)

    # # 数学分支
    # g.setEdge(courses_list[3], courses_list[9], courses_list[9].Ccredit)
    # g.setEdge(courses_list[9], courses_list[40], courses_list[40].Ccredit)
    # g.setEdge(courses_list[14], courses_list[40], courses_list[40].Ccredit)
    # g.setEdge(courses_list[4], courses_list[40], courses_list[40].Ccredit)
    # g.setEdge(courses_list[9], courses_list[43], courses_list[43].Ccredit)
    
    # # 大物分支
    # g.setEdge(courses_list[5], courses_list[11], courses_list[11].Ccredit)
    # g.setEdge(courses_list[5], courses_list[42], courses_list[42].Ccredit)

    # # 离散数学分支
    # g.setEdge(courses_list[19], courses_list[23], courses_list[23].Ccredit)
    # g.setEdge(courses_list[19], courses_list[22], courses_list[22].Ccredit)
    # g.setEdge(courses_list[23], courses_list[45], courses_list[45].Ccredit)
    # g.setEdge(courses_list[23], courses_list[29], courses_list[29].Ccredit)
    # g.setEdge(courses_list[23], courses_list[26], courses_list[26].Ccredit)

    # # C语言分支
    # g.setEdge(courses_list[17], courses_list[46], courses_list[46].Ccredit)
    # g.setEdge(courses_list[17], courses_list[45], courses_list[45].Ccredit)
    # g.setEdge(courses_list[17], courses_list[43], courses_list[43].Ccredit)
    # g.setEdge(courses_list[17], courses_list[29], courses_list[29].Ccredit)
    # g.setEdge(courses_list[17], courses_list[22], courses_list[22].Ccredit)
    # g.setEdge(courses_list[17], courses_list[32], courses_list[32].Ccredit)
    # g.setEdge(courses_list[17], courses_list[37], courses_list[37].Ccredit)
    # g.setEdge(courses_list[17], courses_list[38], courses_list[38].Ccredit)
    # g.setEdge(courses_list[17], courses_list[25], courses_list[25].Ccredit)
    # g.setEdge(courses_list[17], courses_list[41], courses_list[41].Ccredit)
    # g.setEdge(courses_list[17], courses_list[39], courses_list[39].Ccredit)

    # # 电路分支
    # g.setEdge(courses_list[18], courses_list[21], courses_list[21].Ccredit)
    # g.setEdge(courses_list[21], courses_list[20], courses_list[20].Ccredit)

    # # 数据结构分支
    # g.setEdge(courses_list[22], courses_list[45], courses_list[45].Ccredit)
    # g.setEdge(courses_list[22], courses_list[46], courses_list[46].Ccredit)
    # g.setEdge(courses_list[22], courses_list[43], courses_list[43].Ccredit)
    # g.setEdge(courses_list[22], courses_list[36], courses_list[36].Ccredit)
    # g.setEdge(courses_list[22], courses_list[26], courses_list[26].Ccredit)
    # g.setEdge(courses_list[22], courses_list[30], courses_list[30].Ccredit)
    # g.setEdge(courses_list[22], courses_list[29], courses_list[29].Ccredit)
    # g.setEdge(courses_list[26], courses_list[31], courses_list[31].Ccredit) 
    
    # # 数字逻辑分支
    # g.setEdge(courses_list[20], courses_list[24], courses_list[24].Ccredit)
    # g.setEdge(courses_list[24], courses_list[25], courses_list[25].Ccredit)
    # g.setEdge(courses_list[24], courses_list[28], courses_list[28].Ccredit)
    # g.setEdge(courses_list[24], courses_list[44], courses_list[44].Ccredit)
    # g.setEdge(courses_list[24], courses_list[39], courses_list[39].Ccredit)
    # g.setEdge(courses_list[20], courses_list[44], courses_list[44].Ccredit)
    # g.setEdge(courses_list[39], courses_list[44], courses_list[44].Ccredit)
    # g.setEdge(courses_list[20], courses_list[27], courses_list[27].Ccredit)
    # g.setEdge(courses_list[20], courses_list[41], courses_list[41].Ccredit)

    # # 杂&大三选修课
    #     # 数字图像处理
    # g.setEdge(courses_list[4], courses_list[47], courses_list[47].Ccredit)
    # g.setEdge(courses_list[9], courses_list[47], courses_list[47].Ccredit)
    # g.setEdge(courses_list[17], courses_list[47], courses_list[47].Ccredit)
    # g.setEdge(courses_list[22], courses_list[47], courses_list[47].Ccredit)
    #     # 计算机控制原理与技术Ⅱ
    # g.setEdge(courses_list[20], courses_list[48], courses_list[48].Ccredit)
    # g.setEdge(courses_list[24], courses_list[48], courses_list[48].Ccredit)
    # g.setEdge(courses_list[44], courses_list[48], courses_list[48].Ccredit)
    #     # 软件质量管理与测试
    # g.setEdge(courses_list[17], courses_list[49], courses_list[49].Ccredit)
    # g.setEdge(courses_list[22], courses_list[49], courses_list[49].Ccredit)
    # g.setEdge(courses_list[26], courses_list[49], courses_list[49].Ccredit)
    #     # 分布式系统导论（双语）
    # g.setEdge(courses_list[27], courses_list[50], courses_list[50].Ccredit)
    # g.setEdge(courses_list[25], courses_list[50], courses_list[50].Ccredit)
    #     # TCP/IP协议分析及应用Ⅰ
    # g.setEdge(courses_list[27], courses_list[51], courses_list[51].Ccredit)
    #     # 多媒体技术
    # g.setEdge(courses_list[17], courses_list[52], courses_list[52].Ccredit)
    # g.setEdge(courses_list[22], courses_list[52], courses_list[52].Ccredit)
    # g.setEdge(courses_list[24], courses_list[52], courses_list[52].Ccredit)
    # g.setEdge(courses_list[28], courses_list[52], courses_list[52].Ccredit)
    #     # 数字信号处理
    # g.setEdge(courses_list[9], courses_list[53], courses_list[53].Ccredit)
    # g.setEdge(courses_list[4], courses_list[53], courses_list[53].Ccredit)
    # g.setEdge(courses_list[14], courses_list[53], courses_list[53].Ccredit)
    #     # IPv6技术及应用
    # g.setEdge(courses_list[27], courses_list[54], courses_list[54].Ccredit)
    #     # Linux操作系统
    # g.setEdge(courses_list[25], courses_list[55], courses_list[55].Ccredit)
    #     # 数据挖掘
    # g.setEdge(courses_list[17], courses_list[56], courses_list[56].Ccredit)
    # g.setEdge(courses_list[22], courses_list[56], courses_list[56].Ccredit)
    # g.setEdge(courses_list[26], courses_list[56], courses_list[56].Ccredit)
    # g.setEdge(courses_list[14], courses_list[56], courses_list[56].Ccredit)
    #     # SOPC设计技术
    # g.setEdge(courses_list[24], courses_list[57], courses_list[57].Ccredit)
    # g.setEdge(courses_list[41], courses_list[57], courses_list[57].Ccredit)
    # g.setEdge(courses_list[44], courses_list[57], courses_list[57].Ccredit)
    #     # 机器学习基础
    # g.setEdge(courses_list[4], courses_list[58], courses_list[58].Ccredit)
    # g.setEdge(courses_list[9], courses_list[58], courses_list[58].Ccredit)
    # g.setEdge(courses_list[14], courses_list[58], courses_list[58].Ccredit)
    #     # Python与数据分析
    # g.setEdge(courses_list[17], courses_list[59], courses_list[59].Ccredit)
    # g.setEdge(courses_list[22], courses_list[59], courses_list[59].Ccredit)
    #     # 并行计算
    # g.setEdge(courses_list[17], courses_list[60], courses_list[60].Ccredit)
    # g.setEdge(courses_list[28], courses_list[60], courses_list[60].Ccredit)
    # g.setEdge(courses_list[27], courses_list[60], courses_list[60].Ccredit)
    # g.setEdge(courses_list[25], courses_list[60], courses_list[60].Ccredit)
    #     # 嵌入式系统设计技术
    # g.setEdge(courses_list[24], courses_list[61], courses_list[61].Ccredit)
    # g.setEdge(courses_list[17], courses_list[61], courses_list[61].Ccredit)
    #     # 大数据管理与分析
    # g.setEdge(courses_list[22], courses_list[62], courses_list[62].Ccredit)
    # g.setEdge(courses_list[26], courses_list[62], courses_list[62].Ccredit)

    # g.sortG()

    #     # 心理课没边
    # g.addVertex(courses_list[63])

    # file = open('Graph', 'w')
    # file.write(g.saveTo)
    # file.close()

    # 经典验证环节
    # g.printAll()
    # print(g.Indegree)
    # print(g.numEdge)
    # print(g.numVertex)
    # print(g.Mark)
    return g, courses_list



# 建图之后进行拓扑排序分出八个学期的课,findCircle=True仅当当前为手动添课
def topology(g : classes.Graph, cl : list, bar: QtWidgets.QProgressBar, findCircle=False, limit=280.0):
    q = classes.MyQ(g.numVertex)

    sems = []

    for bl in g.Mark:
        bl = False

    if findCircle is False:
        # 一共25个专业选修，按照教学计划选9门即可，因此随机失活16门
        # 280 - 16   ;   500 - 0  --> y = -0.072x + 36
        for i in range(int(-0.072 * limit + 36)):
            aa = random.randint(37, 61)
            g.Mark[aa] = True

    # 找八个学期的课
    for ii in range(8):
        curHour = 0
        # 先找到本学期应该上的课
        sem = []
        for i in range(g.numVertex):
            if g.Indegree[i] == 0 and g.Mark[i] is False:
                # 一旦目前课时即将满(四分之三)，50%随机失活
                if curHour >= limit * 3 / 4 and findCircle is False:
                    aa = random.randint(0, 1)
                    if aa == 1:
                        continue
                # 加入当前课程超时，失活
                if curHour + cl[i].Chour > limit and findCircle is False:
                    continue
                q.enQueue(cl[i])
                sem.append(cl[i])
                cl[i].Csem = i + 1      
                curHour += cl[i].Chour
        bar.setValue(10 * ii)
        sems.append(sem)
        # print('S' + str(ii + 1) + ':', sem)

        # 加入所有先行课的后续课
        while q.isEmpty() is False:
            v = q.deQueue()
            g.Mark[v.Cid] = True
            e = g.firstEdge(v)
            while g.isEdge(e):
                g.Indegree[g.toVertex(e).Cid] -= 1
                e = g.nextEdge(e)

    interact.sems = sems
    # 保存sems
    if findCircle is False:
        semstr = ''
        file = open('sems', 'w')
        for sem in sems:
            for c in sem:
                semstr += str(c.Cid) + ','
            semstr = semstr[:-1] + '\n'
        file.write(semstr)
        file.close()
    else:
        # print(g.Mark)
        if False in g.Mark:
            return False
        else:
            return True
    return sems

# 上课地点随机分配
def addPlace(sems : list):
    tz = pd.read_csv('通州上课地点.csv')
    cy = pd.read_csv('校本部上课地点.csv')

    for j in range(0, 8):
        if j == 0 or j == 1:
            flag = 0
            for i in range(len(sems[j])):
                aa = random.randint(0, len(tz) - 1)
                sems[j][flag].Cplace = tz['上课教室'][aa]
                flag += 1
        else:
            flag = 0
            for i in range(len(sems[j])):
                aa = random.randint(0, len(cy) - 1)
                sems[j][flag].Cplace = cy['上课教室'][aa]
                flag += 1

# 打印每学期课时,和平均课时
def printHour(sems : list):
    sums = 0
    for sem in sems:
        total = 0
        for item in sem:
            total += item.Chour
        sums += total
        print(total)
    print(sums / 8)

# 每一学期的课进行开课时间编排
def arrange_time():
    pass

# 打印八个学期个表
def printSem(sems : list):
    # s = 1
    # for rank in sems:
    #     print('S' + str(s) + ':' + str(rank))
    #     s += 1
    s = 1
    string = ''
    for rank in sems:
        singleElem = ''
        for elem in rank:
            # print(str(elem).split(':')[0])
            singleElem += (str(elem).split('\n')[0] + ' ').split(')')[1]
        # print(singleElem)
        string += 'S' + str(s) + ':' + str(singleElem) + '\n'
        s += 1
    # print(string)
    return string

# 打印排课方案封装
def generate_schedule(bar : QtWidgets.QProgressBar, limit):
    data = load_data()
    interact.algorism.g, courses_list = init_graph(data)
    interact.sems = topology(interact.algorism.g, courses_list, bar, limit=limit)
    addPlace(interact.sems)
    bar.setValue(90)
    return printSem(interact.sems)

# 课表制作
# 每学期的课表应当有1-16周对应的课时容量


# 可选：随机重新生成课表；分开的课别挨着；1学时的课的下一节应该为空，不能有课（学生来不及换班）；教学楼位置
# 还没写判断环

if __name__ == '__main__':
    data = load_data()
    g, courses_list = init_graph(data)
    # sems = topology(g, courses_list)
    # addPlace(sems)
    # printHour(sems)
    # printSem(sems)
    # # 课表:8个学期，上午4学时下午4学时，每学期周一到周五
    # schedule = np.ones([8, 8, 5])
    # schedule = (schedule.astype(int)).astype(classes.courses)
    # print(schedule)
    topology(g, courses_list, QtWidgets.QProgressBar(), True)
    
