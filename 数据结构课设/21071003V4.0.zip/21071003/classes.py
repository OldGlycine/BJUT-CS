# 类定义
import numpy as np

# 队列定义
class MyQ:
    def __init__(self, size):
        self.q = [None for i in range(size)]
        self.front = 0
        self.rear = 0
        self.mSize = size

    def enQueue(self, val):
        if (self.rear + 1) % self.mSize == self.front:
            return False
        else:
            self.q[self.rear] = val
            self.rear = (self.rear + 1) % self.mSize
            return True
        
    def deQueue(self):
        if self.front == self.rear:
            return None
        else:
            val = self.q[self.front]
            self.front = (self.front + 1) % self.mSize
            return val
        
    def getFront(self):
        if self.front == self.rear:
            return None
        else:
            return self.q[self.front]
        
    def print(self):
        print(self.q)

    def isEmpty(self):
        if self.front == self.rear:
            return True
        else:
            return False

# 课程类定义
# 直接作为Graph类的graph字典的vertex值
class courses:
    # 一门课的构成：名字，学分，学时，开设时间限制，推荐选读学期，上课地点, 课程开设时间(隐含)
    # 2学时是一个半小时
    def __init__(self, id, name, credit, hour, limit=1, sem=1, place=''):
        self.Cid = id
        self.Cname = name   
        self.Ccredit = credit       # weight
        # self.Ctime = [] # 开设时间应该为系统自动生成，部分课程时间应当加以限制，有限制的课应当优先获取开设时间
        self.Climit = limit # 开设时间限制为1，那么就代表这门课最好晚上前修读，为2的话就代表最好早上修读，这也代表了优先级
        self.Csem = sem  #  系统自动生成
        # 课程学时
        self.Chour = hour
        self.Cplace = place

    # print类 所输出的内容重载
    def __str__(self) -> str:
        # return f" Course name:{self.Cname} | credit:{self.Ccredit} "
        # return f" {self.Cname} " # 用于测试的简化版
        return f"id({self.Cid}){self.Cname}\n上课地点:{self.Cplace}\n{self.Chour}学时"
    __repr__ = __str__

    # 重载小于等于,排名依据是id
    def __le__(self, other):
        return self.Cid <= other.Cid
    
    # 重载小于
    def __lt__(self, other):
        return self.Cid <= other.Cid
    
    # 重载大于
    def __gt__(self, other):
        return self.Cid > other.Cid

    def setId(self, id):
        self.Cid = id

    def setCname(self, name):
        self.Cname = name

    def setCcredit(self, credit):
        self.Ccredit = credit

    def setCtime(self, time):
        self.Ctime = time
    
    def setClimit(self, lim):
        self.Climit = lim

    def setCsem(self, sem):
        self.Csem = sem

    def setPlace(self, place):
        self.Cplace = place

    def getCcredit(self):
        return self.Ccredit
    
# 边类定义
class Edge:
    # weight可以是学分
    def __init__(self, f=0, t=0, w=0):
        self.Efrom = f
        self.Eto = t
        self.Eweight = w

    def __str__(self) -> str:
        return f" {self.Eto} " 
    __repr__ = __str__

# 图类定义
class Graph:
    def __init__(self, course_num):
        self.graph = {}             # 图类的核心，存储词典，形式形如 'A' : [B(含vertex&weight), C, D]
        self.numVertex = course_num
        self.numEdge = 0
        self.Indegree = [0 for i in range(course_num)]
        self.Outdegree = [0 for i in range(course_num)]
        self.Mark = [False for i in range(course_num)]
        self.saveTo = ''

    # 是否是边
    def isEdge(self, e:Edge):
        if e.Eweight == 0:
            return False
        else:
            return True
        
    # 返回边的终点
    def toVertex(self, e:Edge):
        return e.Eto

    # 寻某图的首边
    def firstEdge(self, oneVertex):
        e = Edge()
        e.Efrom = oneVertex
        # 没找到的情况下,e.Eto=0
        if oneVertex in self.graph.keys():
            if self.graph.get(oneVertex) is None:
                # print('此顶点没边')
                pass
            else:
                e.Eto = self.graph.get(oneVertex)[0]
                e.Eweight = self.graph.get(oneVertex)[0]
        else:
            # print('图中没有此点')
            pass
        return e

    # 寻输入边的下一条边
    def nextEdge(self, preEdge):
        e = Edge()
        e.Efrom = preEdge.Efrom
        temp = self.graph.get(preEdge.Efrom)
        i = -1
        while i + 1 != len(temp) and temp[i + 1] <= preEdge.Eto:
            i += 1
        # NULL的情况
        if i + 1 == len(temp):
            # print('Already last edge,no next edge!')
            pass
        else:
            e.Eto = temp[i + 1]
            e.Eweight = temp[i + 1].getCcredit()
        return e

    # 添加边
    def setEdge(self, f, t, w):
        temp = self.graph.get(f)
        self.saveTo += str(f.Cid) + ',' + str(t.Cid) + '\n'
        i = -1
        if temp is not None:
            while i + 1 != len(temp) and temp[i + 1] < t:
                i += 1
            # 边不存在且最后一条边
            if i + 1 == len(temp):
                self.graph[f].append(t)
                self.numEdge += 1
                self.Indegree[t.Cid] += 1
                self.Outdegree[f.Cid] += 1
            # 边存在就更新权重
            elif temp[i + 1] == t:
                self.graph[f][i + 1].setCcredit(w)
            # 边不存在，但后边还有边
            elif temp[i + 1] > t:
                self.graph[f].insert(i, t)
                self.numEdge += 1
                self.Indegree[t.Cid] += 1
                self.Outdegree[t.Cid] += 1
        else:
            # 创建第一条边
            self.graph[f] = [t]
            self.Indegree[t.Cid] += 1
            self.Outdegree[f.Cid] += 1
            self.numEdge += 1

    # 该课是否可以删除的依据，是该课程是否为入度为0或出度为0
    def canDel(self, c):
        # print(c in self.graph)
        if self.Indegree[c.Cid] == 0 or self.Outdegree[c.Cid] == 0:
            return True
        return False
                
    def addVertex(self, vertex):
        self.graph[vertex] = None
        # self.numVertex += 1 点数在构建时已经规定了
        self.saveTo += str(vertex.Cid) + '\n'

    # 删边
    def delEdge(self, c):
        c_id = c.Cid
        C = None
        for k in self.graph.keys():
            print(k)
            if self.graph[k] != None:
                for kk in self.graph[k]:
                    # print(kk.Cid)
                    if kk.Cid == c_id:
                        C = kk
                        break
            if C != None:
                break
            if k.Cid == c_id:
                C = k
                break
        # 避免因key删除导致找不到val
        if C == None:
            return
        e = self.firstEdge(C)
        while self.isEdge(e):
            self.Indegree[self.toVertex(e).Cid] -= 1
            e = self.nextEdge(e)
        self.Indegree[C.Cid] = 0
        self.Outdegree[C.Cid] = 0
        for k in self.graph.keys():
            if k != C:
                try:
                    self.graph[k].pop(C)
                    self.Outdegree[k.Cid] -= 1
                except:
                    pass
        if C in self.graph:
            self.graph.pop(C)

    def printAll(self):
        for keys, vals in self.graph.items():
            string = ''
            string += '父节点: ' + str(keys) + '->'
            if vals is None:
                string += ' 无子节点' 
            else:
                for val in vals:
                    if val == vals[-1]:
                        string += str(val)
                    else:
                        string += str(val) + '->'
            print(string)

    def sortG(self):
        for key, val in self.graph.items():
            if val is not None:
                val.sort()
            self.graph[key] = val


if __name__ == '__main__':
    # index, 课程名字，学分，学时，开设时间限制
    a = courses(id=1, name='高等数学', credit=5.5, hour=1, limit=1)
    b = courses(id=3, name='低等数学', credit=5.5, hour=2, limit=1)
    c = courses(id=2, name='中等数学', credit=5.5, hour=4, limit=1)
    g = Graph(4)
    g.setEdge(a, b, b.Ccredit)
    g.setEdge(b, c, c.Ccredit)
    g.delEdge(a)
    g.printAll()
    
    # print(g.Indegree)
    # print(g.numEdge)
    # print(g.numVertex)
    # print(g.Mark)
    # print(g.graph)