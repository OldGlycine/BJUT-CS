# 组件交互文件
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QFont, QStandardItem
import Ui_main
from algorism import *
import algorism



model = QtGui.QStandardItemModel(17, 8)
    # 设置行标签
model.setHorizontalHeaderLabels(['第一学期', '第二学期', '第三学期', '第四学期', '第五学期', '第六学期', '第七学期', '第八学期'])
vlist = []
for i in range(17):
    vlist.append('课' + str(i + 1))
vlist.append('总学时')
model.setVerticalHeaderLabels(vlist)

limit=280.0

g = None
courses_list = None
sems = None
_translate = QtCore.QCoreApplication.translate

# 组件测试区
def buttonClickedTest(button):
    print("Clicked")
    
def checkClickedTest(check):
    print("Checked")

def aptest(tb : QtWidgets.QTextBrowser):
    tb.append("222")

# 组件交互区
def schemeGenerate(tb : QtWidgets.QTextBrowser, bar : QtWidgets.QProgressBar, md : QtWidgets.QTableView, ac : list):
    global sems
    for w in ac:
        w.setEnabled(True)
    # clearM()
    tb.setFont(QFont('Adoube Arabic', 11))
    tb.setText(_translate("OldGao_21071003", '推荐选课如下所示(再次点击生成，可重新生成新方案！):\n' + generate_schedule(bar, limit=limit)))

    # 课程添加到表格中
    for j in range(8):
        hours = 0
        for i in range(17):
            if i < len(sems[j]):
                item = QStandardItem(str(sems[j][i]))
                hours += sems[j][i].Chour
                model.setItem(i, j, item)
            else:
                item = QStandardItem(' ')
                model.setItem(i, j, item)
            h = QStandardItem(str(hours))
            model.setItem(17, j, h)
    bar.setValue(100)

def setHour(sp : QtWidgets.QDoubleSpinBox, tb : QtWidgets.QTextBrowser):
    global limit
    limit = sp.value()
    tb.setFont(QFont('Adoube Arabic', 11))
    tb.setText(_translate("OldGao_21071003", '修改成功！现在每学期最大课时修改为：' + str(sp.value())))

def deleteClass(tb : QtWidgets.QTextBrowser, md : QtWidgets.QTableView, sp : QtWidgets.QDoubleSpinBox):
    # 删除sems中的对应课程，注意要错误检测
    flag = 0
    id = int(sp.value())
    global sems
    for sem in sems:
        for course in sem:
            if course.Cid == id:
                # 接下来就是对单元格视图的优化调整
                inner_flag = 0
                for j in range(8):
                    for i in range(16):
                        # 本列课程遍历完毕，跳出到下一列（剪枝）
                        thing = md.model().itemData(md.model().index(i, j))
                        if thing == {0: ' '}:
                            break
                        else:
                            # 分裂查找id
                            c_id = int(thing[0].split('(')[1].split(')')[0])
                            if c_id == id:
                                if g.canDel(course):
                                    sem.remove(course)
                                    flag = 1
                                    tb.setFont(QFont('Adoube Arabic', 11))
                                    tb.setText(_translate("OldGao_21071003", '成功删除课程：' + str(course)) + '\n目前的排课方案更新为:\n' + printSem(interact.sems))
                                    g.delEdge(course)
                                    inner_flag = 1  
                                    # 更改对应总课时
                                    hour_temp = int((thing[0].split('\n')[-1]).split('学时')[0])
                                    hour_total = int(md.model().itemData(md.model().index(17, j))[0])
                                    h = QStandardItem(str(hour_total - hour_temp))
                                    model.setItem(17, j, h)
                                    # 从删除的课开始，顺序往前替换单元格
                                    push_flag = i
                                    while md.model().itemData(md.model().index(push_flag, j)) != {}:
                                        exthing = md.model().itemData(md.model().index(push_flag + 1, j))
                                        if exthing == {0: ' '}:
                                            item = QStandardItem(' ')
                                            md.model().setItem(push_flag, j, item)
                                            break
                                        else:
                                            item = QStandardItem(exthing[0])
                                            md.model().setItem(push_flag, j, item)
                                        push_flag += 1
                                    # 删除sems中对应的课程的id并保存
                                    for sem in sems:
                                        for course in sem:
                                            if course.Cid == id:
                                                sem.pop(course)
                                    semstr = ''
                                    file = open('sems', 'w')
                                    for sem in sems:
                                        for c in sem:
                                            semstr += str(c.Cid) + ','
                                        semstr = semstr[:-1] + '\n'
                                    file.write(semstr)
                                    file.close()
                                    
                                    # 删除Graph文件中对应的建图操作
                                    file = open('Graph', 'r')
                                    gstr = file.read()
                                    file.close()
                                    sgstr = gstr.split('\n')[:-1]
                                    push_i = 0
                                    print(len(sgstr))
                                    while push_i != len(sgstr):
                                        if len(sgstr[push_i].split(',')) == 1:
                                            if int(sgstr[push_i].split(',')[0]) == id:
                                                sgstr.pop(push_i)
                                                push_i -= 1
                                        else:
                                            if int(sgstr[push_i].split(',')[0]) == id:
                                                sgstr.pop(push_i)
                                                push_i -= 1
                                        push_i += 1
                                        if push_i >= len(sgstr):
                                            break
                                    overwrite_str = ''
                                    for sss in sgstr:
                                        overwrite_str += sss + '\n'
                                    file = open('Graph', 'w')
                                    file.write(overwrite_str)
                                    file.close()
                                else:
                                    tb.setFont(QFont('Adoube Arabic', 11))
                                    tb.setText(_translate("OldGao_21071003", '删除课程失败！该课程有先修课或后修课！'))
                                    return
                    if inner_flag == 1:
                        break
        if flag == 1:
            break
    # 错误检验
    if flag == 0:
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '删除课程失败！请检查id是否输入正确！'))
    return 

def activate(lis1, lis2):
    for w in lis1:
        w.setEnabled(False)
    for w in lis2:
        w.setEnabled(True)

def addCourse(tb : QtWidgets.QTextBrowser,
            md : QtWidgets.QTableView,
            courseN : QtWidgets.QTextEdit,
            credit : QtWidgets.QDoubleSpinBox,
            hour : QtWidgets.QSpinBox,
            id : QtWidgets.QSpinBox,
            bar : QtWidgets.QProgressBar):
    
    # c = classes.courses(algorism.total_len, courseN.toPlainText(), credit.value(), hour.value(), limit=1)
    flag = False
    findid = 0

    for css in courses_list:
        if css.Cname == courseN.toPlainText():
            findid = css.Cid
            # tb.setFont(QFont('Adoube Arabic', 11))
            # tb.setText(_translate("OldGao_21071003", '加课失败!已有相同课程!'))
            # return
            flag = True

    if flag == False:
        c = classes.courses(algorism.total_len, courseN.toPlainText(), credit.value(), hour.value(), limit=1)
        courses_list.append(c)

    gg = classes.Graph(len(courses_list))
    addV = []
    file = open('Graph', 'r')
    gstr = file.read()
    for ss in gstr.split('\n')[:-1]:
        if len(ss.split(',')) == 1:
            addV.append(int(ss))
        else:
            num1 = int(ss.split(',')[0])
            num2 = int(ss.split(',')[1])
            gg.setEdge(courses_list[num1], courses_list[num2], courses_list[num2].Ccredit)

    gg.sortG()

    for nums in addV:
        gg.addVertex(courses_list[nums])

    if id.value() == -1:
        gg.addVertex(c)
    elif id.value() < -1:
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '加课失败!id输入错误!'))
        return
    elif id.value() > len(courses_list):
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '加课失败!终点课程不存在!'))
        return
    else:
        if flag == False:
            gg.setEdge(c, courses_list[id.value()], courses_list[id.value()].Ccredit)
        else:
            gg.setEdge(courses_list[findid], courses_list[id.value()], courses_list[id.value()].Ccredit)


    if topology(gg, courses_list, bar,findCircle=True, limit=100000.0) == True:
        courses_list.pop()
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '加课成功!请重新生成排课方案!'))
        # csv导入
        if flag == False:
            import pandas as pd
            df = pd.read_csv('courses.csv')
            lens = len(df)
            df.loc[lens] = ([lens, courseN.toPlainText(), credit.value(), hour.value(), 1])
            df.to_csv('courses.csv', index=False)
        # Graph文件导入
        file = open('Graph', 'a')
        if flag == False:
            ws = str(algorism.total_len)
        else:
            ws = str(findid)
        if id.value() == -1:
            ws += '\n'
        else:
            ws += ',' + str(id.value()) + '\n'
        print('write ' + ws)
        file.write(ws)
        file.close()  

        # 重新覆盖Graph_ori
        file = open('Graph', 'r')
        togstr = file.read()
        file.close()

        file = open('Graph_ori', 'w')
        file.write(togstr)
        file.close()
        bar.setValue(100)
    else:
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '加课失败!该课的加入会构成环!请重新检查先修课id!'))
        print(courses_list[gg.Mark.index(False)])
        bar.setValue(100)
        return
    
def exchangeCourse(tb : QtWidgets.QTextBrowser,
            md : QtWidgets.QTableView,
            exid : QtWidgets.QSpinBox,
            exsem : QtWidgets.QComboBox):
    semid = int(exsem.currentText()) - 1
    c_id = exid.value()
    t_c = None
    t_cnl = None
    # 寻课
    for key in g.graph.keys():
        if key.Cid == c_id:
            t_c = key
            break
        if g.graph[key] is None:
            continue
        for val in g.graph[key]:
            if val.Cid == c_id:
                t_c = val
                break
        if t_c is not None:
            break
    for sem in sems:
        for courses in sem:
            if courses.Cid == c_id:
                t_cnl = courses

    # 先要判断要调换的课所在的列
    find_flag = 0
    for j in range(8):
        for i in range(17):
            thing = md.model().itemData(md.model().index(i, j))
            if thing == {0: ' '}:
                break
            else:
                # 分裂查找id
                f_id = int(thing[0].split('(')[1].split(')')[0])
                # 查找到课表中课程id
                if f_id == c_id:
                    # 找到了该课程在j列中的i行
                    # 首先要判断该课能不能换
                    mincol = 8
                    maxcol = -1
                    # 遍历最大先修课
                    for cols in range(0, j):
                        for courses in sems[cols]:
                            # 寻课，无奈之举
                            t_cc = None
                            for key in g.graph.keys():
                                if key.Cid == courses.Cid:
                                    t_cc = key
                                    break
                                if g.graph[key] is None:
                                    continue
                                for val in g.graph[key]:
                                    if val.Cid == courses.Cid:
                                        t_cc = val
                                        break
                                if t_cc is not None:
                                    break
                            if t_cc is None:
                                continue 
                            if t_cc not in g.graph:
                                continue
                            if g.graph[t_cc] is None:
                                continue
                            if t_c in g.graph[t_cc]:
                                maxcol = max(maxcol, cols)
                                # print(maxcol)
                                
                    # 遍历最小后修课
                    for cols in range(j+1, 8):
                        for courses in sems[cols]:
                            # 寻课，无奈之举
                            t_cc = None
                            for key in g.graph.keys():
                                if key.Cid == courses.Cid:
                                    t_cc = key
                                    break
                                if g.graph[key] is None:
                                    continue
                                for val in g.graph[key]:
                                    if val.Cid == courses.Cid:
                                        t_cc = val
                                        break
                                if t_cc is not None:
                                    break
                            if t_cc is None:
                                continue
                            if t_c not in g.graph:
                                continue
                            if g.graph[t_c] is None:
                                continue
                            if t_cc in g.graph[t_c]:
                                mincol = min(mincol, cols)
                                # print(mincol)

                    # 判断是否能调换
                    if semid <= maxcol or semid >= mincol or semid == j:
                        tb.setFont(QFont('Adoube Arabic', 11))
                        tb.setText(_translate("OldGao_21071003", '换课失败!学期未更变，或要换到的学期有被换课程的先修课或后修课!'))
                        return
                    # 能替换
                    else:
                        # 首先在要换的学期末尾添加本课程
                        thing = md.model().itemData(md.model().index(i, j))[0]
                        item = QStandardItem(thing)
                        md.model().setItem(len(sems[semid]), semid, item)
                        # 原列向上调换
                            # 从删除的课开始，顺序往前替换单元格
                        push_flag = i
                        while md.model().itemData(md.model().index(push_flag, j)) != {}:
                            exthing = md.model().itemData(md.model().index(push_flag + 1, j))
                            if exthing == {0: ' '}:
                                item = QStandardItem(' ')
                                md.model().setItem(push_flag, j, item)
                                break
                            else:
                                item = QStandardItem(exthing[0])
                                md.model().setItem(push_flag, j, item)
                            push_flag += 1
                        # 课时改变
                        hour_temp = int((thing.split('\n')[-1]).split('学时')[0])
                        hour_total_ori = int(md.model().itemData(md.model().index(17, j))[0])
                        hour_total_tar = int(md.model().itemData(md.model().index(17, semid))[0])
                        h_ori = QStandardItem(str(hour_total_ori - hour_temp))
                        h_tar = QStandardItem(str(hour_total_tar + hour_temp))
                            # 原列课时改变
                        model.setItem(17, j, h_ori)
                            # 新列课时改变
                        model.setItem(17, semid, h_tar)
                           
                        # 最后别忘了sems改变并保存
                        sems[j].pop(sems[j].index(t_cnl))
                        sems[semid].append(t_cnl)
                        semstr = ''
                        file = open('sems', 'w')
                        for sem in sems:
                            for c in sem:
                                semstr += str(c.Cid) + ','
                            semstr = semstr[:-1] + '\n'
                        file.write(semstr)
                        file.close()
                        # flag = 1
                        find_flag = 1
                        # 终于成功了
                        tb.setFont(QFont('Adoube Arabic', 11))
                        tb.setText(_translate("OldGao_21071003", '换课成功'))
                        return
        if find_flag == 1:
            break
    if find_flag == 0:
        tb.setFont(QFont('Adoube Arabic', 11))
        tb.setText(_translate("OldGao_21071003", '换课失败!未在课表中查到此课!'))

# 绘画函数
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt

def draw(tb : QtWidgets.QTextBrowser):
    # 创建有向无环图
    G = nx.DiGraph()

    # i = 0

    file = open('Graph', 'r')
    gstr = file.read()
    for ss in gstr.split('\n')[:-1]:
        if len(ss.split(',')) == 1:
            G.add_node(int(ss))
        else:
            num1 = int(ss.split(',')[0])
            num2 = int(ss.split(',')[1])
            G.add_node(num1)
            G.add_node(num2)
            G.add_edge(num1, num2)
        # i += 1
        # if i >= 40:
        #     break

    # 可视化DAG
    pos = graphviz_layout(G, prog='dot')
    nx.draw_networkx(G, pos, arrows=True, with_labels=True)
    plt.show()
    
    tb.setFont(QFont('Adoube Arabic', 11))
    tb.setText(_translate("OldGao_21071003", '生成拓扑图成功,请注意保存!'))

def optionSave(tb : QtWidgets.QTextBrowser, md : QtWidgets.QTableView):
    # Graph和sems直接copy
    file = open('Graph', 'r')
    gstr_old = file.read()
    file.close()
    file = open('Graph_save', 'w')
    gstr_new = gstr_old
    file.write(gstr_new)
    file.close

    file = open('sems', 'r')
    sstr_old = file.read()
    file.close()
    file = open('sems_save', 'w')
    sstr_new = sstr_old
    file.write(sstr_new)
    file.close()

    # model保存逐单元格保存,老规矩碰到空就break
    # 按照学期来存储，这样好和sems进行对照
    # 每一个学期不要忘记保存学时
    mstr = ''
    for j in range(8):
        for i in range(18):
            thing = md.model().itemData(md.model().index(i, j))[0]
            mstr += thing + '\n' + 'λ'
    file = open('model', 'w')
    file.write(mstr)
    file.close()

    tb.setFont(QFont('Adoube Arabic', 11))
    tb.setText(_translate("OldGao_21071003", '保存排课方案成功!详见sems_save,courses_save.csv,Graph_save,model文件!'))

    # 保存csv表格，主要是把上课地点保存
    df = pd.read_csv('courses.csv')
    df['上课地点'] = '待定'
    for sem in sems:
        for courses in sem:
            c_id = courses.Cid
            df.loc[df['id'] == c_id, '上课地点'] = courses.Cplace
    df.to_csv('courses_save.csv', index=False)

# 读取之后会使一些功能失活
def optionLoad(tb : QtWidgets.QTextBrowser, md : QtWidgets.QTableView, l1 : list, l2 : list):        
    for l in l1:
        l.setEnabled(False)
    for l in l2:
        l.setEnabled(True)

    global courses_list
    courses_list = []
    # 读取course_list
    data = pd.read_csv('courses_save.csv')
    algorism.total_len = len(data)
    for i in range(len(data)):
        courses_list.append(classes.courses(
            id=data['id'][i].astype(int),
              name=data['课程名称'][i],
              credit=data['学分'][i].astype(float),
              hour=data['学时'][i].astype(int),
              limit=data['开设时间限制'][i].astype(bool),
              place=data['上课地点'][i]))

    global g
    g = classes.Graph(len(courses_list))
    # 读取Graph
    addV = []
    file = open('Graph_save', 'r')
    gstr = file.read()
    for ss in gstr.split('\n')[:-1]:
        if len(ss.split(',')) == 1:
            addV.append(int(ss))
        else:
            num1 = int(ss.split(',')[0])
            num2 = int(ss.split(',')[1])
            g.setEdge(courses_list[num1], courses_list[num2], courses_list[num2].Ccredit)

    g.sortG()

    for nums in addV:
        g.addVertex(courses_list[nums])
    file.close()
    
    # 重新覆盖Graph
    file = open('Graph_save', 'r')
    togstr = file.read()
    file.close()

    file = open('Graph', 'w')
    file.write(togstr)
    file.close()

    # 读取sems
    global sems
    sems = []
    file = open('sems_save', 'r')
    sstr = file.read()[:-1]
    for unit in sstr.split('\n'):
        tunit = list(map(lambda x :int(x), unit.split(',')))
        sem = []
        for uu in tunit:
            for courses in courses_list:
                if courses.Cid == uu:
                    sem.append(courses)
        sems.append(sem)
    file.close()

    # 读取model并显示
    file = open('model', 'r')
    mstr = file.read()
    i, j = -1, 0
    for unit in mstr.split('λ')[:-1]:
        i += 1
        item = QStandardItem(unit[:-1])
        model.setItem(i, j, item)
        if i == 17:
            i = -1
            j += 1
    file.close()

    tb.setFont(QFont('Adoube Arabic', 11))
    tb.setText(_translate("OldGao_21071003", '读取排课方案成功!退出前请注意及时保存!'))
        
