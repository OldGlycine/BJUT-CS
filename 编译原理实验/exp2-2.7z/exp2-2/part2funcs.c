#include "part2.h"

void print2file(char *s){
    extern FILE* o;
    printf("%s", s);
    fprintf(o, "%s", s);
}

void yyerror(char* s, ...){
    printf("%s\n", s);
}

struct node* newnode(int len, char* name, struct node* brothers[]){
    struct node* new = malloc(sizeof(struct node));
    if(!new) exit(0);
    new->name = name;
    new->child = brothers[0];
    for(int i=0; i<len-1; i++){
        brothers[i]->brother = brothers[i+1];
    }

    return new;
}

struct node* newleaf(char* name){
    struct node* t = malloc(sizeof(struct node));
    if(!t) exit(0);
    t->name = name;
    t->brother = NULL;
    t->child = NULL;

    return t;    
};

void traverse(int depth, struct node* root){
    // for(int i=0; i<depth; i++) printf("-");
    // printf("%s\n", root->name);
    for(int i=0; i<depth; i++) print2file("-");
    print2file(root->name);
    print2file("\n");

    if(root->child != NULL) traverse(depth+2, root->child);
    if(root->brother != NULL) traverse(depth, root->brother);
}

void treefree(struct node* root){
    if(root->child!= NULL && root->child->child == NULL && root->child->brother == NULL){
        free(root->child);
        root->child = NULL;
    }
    if(root->brother!= NULL && root->brother->child == NULL && root->brother->brother == NULL){
        free(root->brother);
        root->brother = NULL;
    }
    if(root->child != NULL) treefree(root->child);
    if(root->brother != NULL) treefree(root->brother);
}

int main(){
    f = fopen("input.txt", "r");
    o = fopen("output.txt", "w");
    extern FILE *yyin;
    yyin = f;
    return yyparse();
}