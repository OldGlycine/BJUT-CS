#include <stdio.h>
#include <stdlib.h>
FILE *f;
FILE *o;

void print2file(char *s);

void yyerror(char* s, ...);

struct node{
    char* name;
    struct node* child;
    struct node* brother;
};


struct node* newnode(int len, char* name, struct node* brothers[]);

struct node* newleaf(char* name);

void traverse(int, struct node*);

void treefree(struct node* n);