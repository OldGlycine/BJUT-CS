#include "exp3.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int totalTemp = 0;
int totalLabel = 0;

int pushFlag = 0;
int * flag = &pushFlag;

char* codes[50];

void gen_txt(char *s){
    extern FILE* o;
    printf("%s", s);
    fprintf(o, "%s", s);
}

void yyerror(char* s, ...){
    printf("%s\n", s);
    fprintf(o, "%s\n", s);
}

char * num2dec(char * s, int base){
    long int num = strtol(s, NULL, base);
    s = malloc(sizeof(char)*10);
    memset(s, 0, sizeof(s));
    sprintf(s, "%ld", num);

    return s;
}

struct block * newBlock(char*bPlace, int * flag, char *codes[50], char* bTrue, char* bFalse, char* begin, char*next){
    struct block* b = (struct block*)malloc(sizeof(struct block));
    if(!b) exit(0);

    // initial
    b->begin = ""; b->next = "";
    b->bCode = ""; b->bFalse = ""; b->bPlace = ""; b->bTrue = "";

    // bPlace
    if(bPlace != NULL)  b->bPlace = bPlace;

    // bTrue
    if(bTrue != NULL)   b->bTrue = bTrue;

    // bFalse
    if(bFalse != NULL)  b->bFalse = bFalse;

    // bCode
    // b->bCode = (char*)malloc((sizeof(char) * ((*flag) + 1)));
    for(int i = 0; i < (*flag); i++)  {b->bCode = strcat_new(b->bCode, codes[i]);}
    // printf("【node】place:%s code:%s true:%s false:%s\n", b->bPlace, b->bCode, b->bTrue, b->bFalse);
    return b;
}

void gen_J(char* label){
    codes[(*flag)++] = label;
    codes[(*flag)++] = ":\n";
}

void gen_GOTO(char * s_next){
    codes[(*flag)++] = "goto ";
    codes[(*flag)++] = s_next;
    codes[(*flag)++] = "\n";
}

void gen_GOTOWHILE(char* s_begin){
    codes[(*flag)++] = "goto ";
    codes[(*flag)++] = s_begin;
    codes[(*flag)++] = "\n";
}

void gen_EQ(char*place1, char*place2){
    codes[(*flag)++] = place1;
    codes[(*flag)++] = " := ";
    codes[(*flag)++] = place2;
    codes[(*flag)++] = "\n";
}

void gen_IF(char*place1, char*op, char*place2, char*true_label, char*false_label){
    codes[(*flag)++] = "if ";
    codes[(*flag)++] = place1;
    codes[(*flag)++] = op;
    codes[(*flag)++] = place2;
    codes[(*flag)++] = " goto ";
    codes[(*flag)++] = true_label;
    codes[(*flag)++] = "\ngoto ";
    codes[(*flag)++] = false_label;
    codes[(*flag)++] = "\n\0";
}

void gen_ET(char*place1, char*place2, char*op, char*place3){
    codes[(*flag)++] = place1;
    codes[(*flag)++] = " := ";
    codes[(*flag)++] = place2;
    codes[(*flag)++] = op;  
    codes[(*flag)++] = place3;
    codes[(*flag)++] = "\n\0";
}

char * newtemp(){
    char *n_temp = "t";
    char temp_number[10];
    memset(temp_number, 0, sizeof(temp_number));
    sprintf(temp_number, "%d", totalTemp++);
    return strcat_new(n_temp, temp_number);
}

char * newlabel(){
    char *n_label = "L";
    char label_number[10];
    memset(label_number, 0, sizeof(label_number));
    sprintf(label_number, "%d", totalLabel++);
    return strcat_new(n_label, label_number);;
}

char* strcat_new(char * a, char * b){
    int lena = strlen(a), lenb = strlen(b);
    int len = lena + lenb + 1;
    char * output = (char*)malloc(sizeof(char) * len);
    for(int i = 0; i < lena; i++)   output[i] = a[i];
    for(int i = 0; i + lena < len - 1; i++) output[i + lena] = b[i];
    output[len - 1] = '\0';
    return output;
}

int main(){
    f = fopen("input.txt", "r");
    o = fopen("output.txt", "w");
    extern FILE *yyin;
    yyin = f;
    return yyparse();
}