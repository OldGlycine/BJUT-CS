#include <stdio.h>
#include <stdlib.h>

#define TMODE -100
#define EMODE -101
#define CMODE -102
#define IFMODE1 -103
#define IFMODE2 -104
#define WHILEMODE -105

FILE *f;
FILE *o;

struct block{
    char * bCode;
    char * bPlace;
    char * bTrue;
    char * bFalse;
    char * begin;
    char * next;
};

void gen_txt(char *s);

void yyerror(char* s, ...);

void gen_J(char* label);

void gen_GOTO(char* s_next);

void gen_GOTOWHILE(char* s_begin);

void gen_EQ(char*place1, char*place2);

void gen_IF(char*place1, char*op, char*place2, char* true_label, char* false_label);

void gen_ET(char*place1, char*place2, char*op, char*place3);

struct block * newBlock(char*bPlace, int * flag, char *codes[50], char* bTrue, char* bFalse, char* begin, char* next);

char * newtemp();

char * newlabel();

char * num2dec(char * s, int base);

char* strcat_new(char * a, char * b);