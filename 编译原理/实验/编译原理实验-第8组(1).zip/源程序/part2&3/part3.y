%{
#include <stdio.h>
#include <stdlib.h>
#include "part3.h"
#include <string.h>
int yydebug = 1;

char* strlist[50];

%}
%union{
    struct node *n;
    char* val;
}

%token EOL
%token <val> IDN DEC OCT HEX
%token <val> PLUS MINUS MULTIPLY DIVIDE
%token <val> G L EQ GE LE NE LP RP LBP RBP
%token <val> IF THEN ELSE WHILE DO

%type <n> para lexs elem term fina stat cond 

%start allinall

%%
allinall:
| allinall para EOL {print2file($2->code);}
| allinall EOL {}
| allinall error EOL {yyerrok;}
;

para: lexs {$$ = $1;}
| lexs para {strlist[0] = $1->code;
            strlist[1] = $2->code;
            $$ = newnode(NULL, strlist, 2, NULL, NULL);
            }
;

lexs: stat {$$ = $1;}
;

stat: IDN EQ elem {
                strlist[0] = $3->code;
                strlist[1] = $1;
                strlist[2] = " := ";
                strlist[3] = $3->place;
                strlist[4] = "\n";
                $$ = newnode(NULL, strlist, 5, NULL, NULL);
                }
| IF cond LBP THEN stat RBP ELSE stat {
                            strlist[0] = $2->code;
                            strlist[1] = $2->_true;
                            strlist[2] = ":\n";
                            strlist[3] = $5->code;
                            strlist[4] = "goto ";
                            strlist[5] = newlable();
                            strlist[6] = "\n";
                            strlist[7] = $2->_false;
                            strlist[8] = ":\n";
                            strlist[9] = $8->code;
                            strlist[10] = strlist[5]; 
                            strlist[11] = ":\n";
                            $$ = newnode(NULL, strlist, 12, NULL, NULL);
                            }
| IF cond THEN stat {
                    strlist[0] = $2->code;
                    strlist[1] = $2->_true;
                    strlist[2] = ":\n";
                    strlist[3] = $4->code;
                    strlist[4] = $2->_false;
                    strlist[5] = ":\n";
                    $$ = newnode(NULL, strlist, 6, NULL, NULL);
                    }
| WHILE cond DO stat {
                    strlist[0] = newlable();
                    strlist[1] = ":\n";
                    strlist[2] = $2->code;
                    strlist[3] = $2->_true;
                    strlist[4] = ":\n";
                    strlist[5] = $4->code;
                    strlist[6] = "goto ";
                    strlist[7] = strlist[0];
                    strlist[8] = "\n";
                    strlist[9] = $2->_false;
                    strlist[10] = ":\n";
                    $$ = newnode(NULL, strlist, 11, NULL, NULL);
                    }
;

cond: elem G elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " > ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[7], strlist[9]);
                }
| elem L elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " < ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[7], strlist[9]);
                }
| elem EQ elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " = ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[7], strlist[9]);
                }
| elem GE elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " < ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[9], strlist[7]);
                }
| elem LE elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " > ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[9], strlist[7]);
                }
| elem NE elem {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = "if ";
                strlist[3] = $1->place;
                strlist[4] = " = ";
                strlist[5] = $3->place;
                strlist[6] = " goto ";
                strlist[7] = newlable();
                strlist[8] = "\ngoto ";
                strlist[9] = newlable();
                strlist[10] = "\n";
                $$ = newnode(NULL, strlist, 11, strlist[9], strlist[7]);
                }
;

elem: term {$$ = $1;}
| elem PLUS term {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = newtemp();
                strlist[3] = " := ";
                strlist[4] = $1->place;
                strlist[5] = " + ";
                strlist[6] = $3->place;
                strlist[7] = "\n";
                $$ = newnode(strlist[2], strlist, 8, NULL, NULL);
                }
| elem MINUS term {
                strlist[0] = $1->code;
                strlist[1] = $3->code;
                strlist[2] = newtemp();
                strlist[3] = " := ";
                strlist[4] = $1->place;
                strlist[5] = " - ";
                strlist[6] = $3->place;
                strlist[7] = "\n";
                $$ = newnode(strlist[2], strlist, 8, NULL, NULL);
                }
;

term: fina {$$ = $1;}
| term MULTIPLY fina {
                    strlist[0] = $1->code;
                    strlist[1] = $3->code;
                    strlist[2] = newtemp();
                    strlist[3] = " := ";
                    strlist[4] = $1->place;
                    strlist[5] = " * ";
                    strlist[6] = $3->place;
                    strlist[7] = "\n";
                    $$ = newnode(strlist[2], strlist, 8, NULL, NULL);
                    }
| term DIVIDE fina {
                    strlist[0] = $1->code;
                    strlist[1] = $3->code;
                    strlist[2] = newtemp();
                    strlist[3] = " := ";
                    strlist[4] = $1->place;
                    strlist[5] = " / ";
                    strlist[6] = $3->place;
                    strlist[7] = "\n\0";
                    $$ = newnode(strlist[2], strlist, 8, NULL, NULL);
                    }
;

fina: LP elem RP {$$ = $2;}
| IDN {$$ = newnode($1, NULL, 0, NULL, NULL);}
| DEC {$$ = newnode($1, NULL, 0, NULL, NULL);
        }
| OCT {$$ = newnode(atoa($1,8), NULL, 0, NULL, NULL);
        }
| HEX {$$ = newnode(atoa($1,16), NULL, 0, NULL, NULL);}
;

%%