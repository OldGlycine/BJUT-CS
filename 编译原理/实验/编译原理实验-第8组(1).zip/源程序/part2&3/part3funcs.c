#include "part3.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int lable_num = 0;
int temp_num = 0;

void print2file(char *s){
    extern FILE* o;
    printf("%s", s);
    fprintf(o, "%s", s);
}

void yyerror(char* s, ...){
    printf("%s\n", s);
}

struct node* newnode(char* place, char* strlist[50], int strnum, char* _true, char* _false){
    struct node* new = (struct node*)malloc(sizeof(struct node));
    if(!new) exit(0);

    new->place = (char*)(malloc(sizeof(char)));
    new->place[0] = '\0';

    new->code = (char*)(malloc(sizeof(char)));
    new->code[0] = '\0';

    new->_true = (char*)(malloc(sizeof(char)));
    new->_true[0] = '\0';

    new->_false = (char*)(malloc(sizeof(char)));
    new->_false[0] = '\0';


    if(place!=NULL && !strcmp(place, NEWTEMP)){
        new->place = newtemp();
    }
    else if(place!=NULL){
        int length = strlen(new->place) + strlen(place) + 1;
        new->place = strcat_ss(new->place, length, place);
    }

    
    for(int i=0; i<strnum; i++){
        int length = strlen(new->code) + strlen(strlist[i]) + 1;
        new->code = strcat_ss(new->code, length, strlist[i]);
    }

    if(_true!=NULL && !strcmp(_true, NEWLABLE)){
        new->_true = newlable();
    }
    else if(_true!=NULL){
        int length = strlen(new->_true) + strlen(_true) + 1;
        new->_true = strcat_ss(new->_true, length, _true);
    }

    if(_false!=NULL && !strcmp(_false, NEWLABLE)){
        new->_false = newlable();
    }
    else if(_false!=NULL){
        int length = strlen(new->_false) + strlen(_false) + 1;
        new->_false = strcat_ss(new->_false, length, _false);
    }

    return new;
}

char* newlable(){
    char* lable = "L";
    char num[10];
    memset(num, 0, sizeof(num));
    sprintf(num, "%d", lable_num);
    lable_num++;

    int len = strlen(lable) + strlen(num) + 1;
    return strcat_ss(lable, len, num);
}

char* newtemp(){
    char* temp = "t";
    char num[10];
    memset(num, 0, sizeof(num));
    sprintf(num, "%d", temp_num);
    temp_num++;

    int len = strlen(temp) + strlen(num) + 1;
    return strcat_ss(temp, len, num);
}

char* strcat_ss(char* deter, int len, char* souce){
    // printf(" !%s",deter);
    // printf(" !!%s", souce);
    // printf(" ~%d\n",len);
    char *res = (char*)malloc(sizeof(char)*len);
    int l_deter = strlen(deter);
    int l_souce = strlen(souce);
    for(int i=0;i<l_deter;i++){
        res[i] = deter[i];
    }
    for(int i=0;i+l_deter<len-1;i++){
        res[l_deter+i] = souce[i]; 
    }
    res[len-1] = '\0';
    return res;
}

char* atoa(char* s, int base){
    long int num = strtol(s, NULL, base);
    s = malloc(sizeof(char)*11);
    memset(s, 0, sizeof(s));
    sprintf(s, "%ld", num);
    return s;
}

int main(){
    f = fopen("input.txt", "r");
    o = fopen("output.txt", "w");
    extern FILE *yyin;
    yyin = f;
    return yyparse();
}