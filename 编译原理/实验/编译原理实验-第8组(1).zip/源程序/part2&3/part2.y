%{
#include <stdio.h>
#include <stdlib.h>
#include "part2.h"
int yydebug = 1;
%}
%union{
    char *c;
}

%token <c> IDN DEC OCT HEX
%token EOL
%token GE LE NE
%token IF THEN ELSE WHILE DO

%start allinall

%%
allinall:
| allinall para EOL {}
| allinall EOL {}
;

para: lexs {print2file("P <= L\n");}
| lexs para {print2file("P <= LP\n");}
;

lexs: stat EOL {print2file("L <= S\n");}
;

stat: IDN '=' elem {print2file("S <= id = E\n");}
| IF cond '{' THEN stat '}' ELSE stat {print2file("S <= if C then S else S\n");}
| IF cond THEN stat {print2file("S <= if C then S\n");}
| WHILE cond DO stat {print2file("S <= while C do S\n");}
;

cond: elem '>' elem {print2file("C <= E > E\n");}
| elem '<' elem {print2file("C <= E < E\n");}
| elem '=' elem {print2file("C <= E = E\n");}
| elem GE elem {print2file("C <= E >= E\n");}
| elem LE elem {print2file("C <= E <= E\n");}
| elem NE elem {print2file("C <= E != E\n");}
;

elem: term
| elem '+' term {print2file("E <= E + T\n");}     
| elem '-' term {print2file("E <= E - T\n");}
;

term: fina
| term '*' fina {print2file("T <= T * F\n");}
| term '/' fina {print2file("T <= T / F\n");}
;

fina: '(' elem ')' {print2file("F <= ( E )\n");}
| IDN {print2file("F <= ID\n");}
| DEC {print2file("F <= DEC\n");}
| OCT {print2file("F <= OCT\n");}
| HEX {print2file("F <= HEX\n");}
;

%%
