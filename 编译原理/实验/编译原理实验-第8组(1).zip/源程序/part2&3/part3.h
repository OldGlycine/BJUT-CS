#include <stdio.h>
#include <stdlib.h>

#define NEWLABLE "-3"
#define NEWTEMP "-2" 

FILE *f;
FILE *o;

void print2file(char *s);

void yyerror(char* s, ...);

// struct baseNode{
//     char* place;
//     char* code;
// };

struct node{
    char* place;
    char* code;
    char* _true;
    char* _false;
};

// struct sNode{
//     char* place;
//     char* code;
//     char* begin;
//     char* end;
// };

char* strcat_ss(char* deter, int len, char* souce);

char* newlable();

char* newtemp();

char* atoa(char* s, int base);

struct node* newnode(char* place, char* strlist[50], int strnum, char* _true, char* _false);

// struct node* newnode(int len, char* name, struct node* brothers[]);

// struct node* newleaf(char* name);

// void traverse(int, struct node*);

// void treefree(struct node* n);