%{
#include <stdio.h>
#include <stdlib.h>
#include "part2.h"
int yydebug = 1;

struct node* nodeList[10];
%}
%union{
    struct node *node;
}

%token EOL
%token <node> IDN DEC OCT HEX
%token <node> PLUS MINUS MULTIPLY DIVIDE
%token <node> G L EQ GE LE NE LP RP LBP RBP
%token <node> IF THEN ELSE WHILE DO

%type <node> para lexs stat cond elem term fina

%start allinall

%%
allinall:
| allinall para EOL {traverse(0, $2); treefree($2);}
| allinall EOL {}
| allinall error EOL {yyerrok;}
;

para: lexs {nodeList[0] = $1;
                  $$ = newnode(1, "P", nodeList);}
| lexs para {nodeList[0] = $1;
             nodeList[1] = $2;
                  $$ = newnode(2, "P", nodeList);}
;

lexs: stat {nodeList[0] = $1;
                  $$ = newnode(1, "L", nodeList);}
;

stat: IDN EQ elem {nodeList[0] = newleaf("ID");
                  nodeList[1] = newleaf("EQ");
                  nodeList[2] = $3;
                  $$ = newnode(3, "S", nodeList);}
| IF cond LBP THEN stat RBP ELSE stat {nodeList[0] = newleaf("IF");
                  nodeList[1] = $2;
                  nodeList[2] = newleaf("THEN");
                  nodeList[3] = $5;
                  nodeList[4] = newleaf("ELSE");
                  nodeList[5] = $8;
                  $$ = newnode(6, "S", nodeList);}
| IF cond THEN stat {nodeList[0] = newleaf("IF");
                  nodeList[1] = $2;
                  nodeList[2] = newleaf("THEN");
                  nodeList[3] = $4;
                  $$ = newnode(4, "S", nodeList);}
| WHILE cond DO stat {nodeList[0] = newleaf("WHILE");
                  nodeList[1] = $2;
                  nodeList[2] = newleaf("DO");
                  nodeList[3] = $4;
                  $$ = newnode(4, "S", nodeList);}
;

cond: elem G elem {nodeList[0] = $1;
                  nodeList[1] = newleaf(">");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
| elem L elem {nodeList[0] = $1;
                  nodeList[1] = newleaf("<");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
| elem EQ elem {nodeList[0] = $1;
                  nodeList[1] = newleaf("=");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
| elem GE elem {nodeList[0] = $1;
                  nodeList[1] = newleaf(">=");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
| elem LE elem {nodeList[0] = $1;
                  nodeList[1] = newleaf("<=");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
| elem NE elem {nodeList[0] = $1;
                  nodeList[1] = newleaf("!=");
                  nodeList[2] = $3;
                  $$ = newnode(3, "C", nodeList);}
;

elem: term {nodeList[0] = $1;
                  $$ = newnode(1, "E", nodeList);}
| elem PLUS term {nodeList[0] = $1;
                  nodeList[1] = newleaf("+");
                  nodeList[2] = $3;
                  $$ = newnode(3, "E", nodeList);}
| elem MINUS term {nodeList[0] = $1;
                  nodeList[1] = newleaf("-");
                  nodeList[2] = $3;
                  $$ = newnode(3, "E", nodeList);}
;

term: fina {nodeList[0] = $1;
                  $$ = newnode(1, "T", nodeList);}
| term MULTIPLY fina {nodeList[0] = $1;
                  nodeList[1] = newleaf("*");
                  nodeList[2] = $3;
                  $$ = newnode(3, "T", nodeList);}
| term DIVIDE fina {nodeList[0] = $1;
                  nodeList[1] = newleaf("/");
                  nodeList[2] = $3;
                  $$ = newnode(3, "T", nodeList);}
;

fina: LP elem RP {nodeList[0] = newleaf("(");
                  nodeList[1] = $2;
                  nodeList[2] = newleaf(")");
                  $$ = newnode(3, "F", nodeList);}
| IDN {nodeList[0] = newleaf("ID");
                  $$ = newnode(1, "F", nodeList);}
| DEC {nodeList[0] = newleaf("DEC");
                  $$ = newnode(1, "F", nodeList);}
| OCT {nodeList[0] = newleaf("OCT");
                  $$ = newnode(1, "F", nodeList);}
| HEX {nodeList[0] = newleaf("HEX");
                  $$ = newnode(1, "F", nodeList);}
;

%%