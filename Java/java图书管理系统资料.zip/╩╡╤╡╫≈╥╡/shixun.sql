/*
Navicat MySQL Data Transfer

Source Server         : sjk
Source Server Version : 80029
Source Host           : localhost:3306
Source Database       : shixun

Target Server Type    : MYSQL
Target Server Version : 80029
File Encoding         : 65001

Date: 2022-06-16 20:03:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for jyhs
-- ----------------------------
DROP TABLE IF EXISTS `jyhs`;
CREATE TABLE `jyhs` (
  `借阅编号` int NOT NULL AUTO_INCREMENT,
  `姓名` varchar(255) NOT NULL,
  `借阅总天数` int NOT NULL,
  `借阅图书名称` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `借阅图书数量` int NOT NULL,
  `借阅时间` date NOT NULL,
  `还书时间` date NOT NULL,
  PRIMARY KEY (`借阅编号`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of jyhs
-- ----------------------------

-- ----------------------------
-- Table structure for tsgj
-- ----------------------------
DROP TABLE IF EXISTS `tsgj`;
CREATE TABLE `tsgj` (
  `图书ID` int NOT NULL AUTO_INCREMENT,
  `图书名称` varchar(255) NOT NULL,
  `图书作者` varchar(255) NOT NULL,
  `图书总数量` int NOT NULL,
  `图书可借数量` int NOT NULL,
  PRIMARY KEY (`图书ID`)
) ENGINE=InnoDB AUTO_INCREMENT=465 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of tsgj
-- ----------------------------
INSERT INTO `tsgj` VALUES ('1', '红楼梦', '曹雪芹', '20', '20');
INSERT INTO `tsgj` VALUES ('2', '三国演义', '吴承恩', '20', '20');
INSERT INTO `tsgj` VALUES ('3', '道德经', '老子', '10', '10');
INSERT INTO `tsgj` VALUES ('4', '黄帝内经', '黄帝', '20', '20');
INSERT INTO `tsgj` VALUES ('5', '白夜行', '东野圭吾', '5', '5');
INSERT INTO `tsgj` VALUES ('6', '心理罪', '雷米', '6', '6');
INSERT INTO `tsgj` VALUES ('7', '活着', ' ', '6', '6');

-- ----------------------------
-- Table structure for zhmm
-- ----------------------------
DROP TABLE IF EXISTS `zhmm`;
CREATE TABLE `zhmm` (
  `用户名` varchar(255) NOT NULL,
  `密码` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`用户名`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of zhmm
-- ----------------------------
INSERT INTO `zhmm` VALUES ('111', '1');
INSERT INTO `zhmm` VALUES ('1111', '123');
INSERT INTO `zhmm` VALUES ('1213', '131');
INSERT INTO `zhmm` VALUES ('123', '123');
INSERT INTO `zhmm` VALUES ('1234', '123');
INSERT INTO `zhmm` VALUES ('12345', '123');
INSERT INTO `zhmm` VALUES ('1236', '1');
INSERT INTO `zhmm` VALUES ('136', '1');
INSERT INTO `zhmm` VALUES ('197', '197');
INSERT INTO `zhmm` VALUES ('66', '66');
INSERT INTO `zhmm` VALUES ('aa', '123');
INSERT INTO `zhmm` VALUES ('aaa', '123');
INSERT INTO `zhmm` VALUES ('aaa1', 'aaa');
INSERT INTO `zhmm` VALUES ('aaaa', '123');
INSERT INTO `zhmm` VALUES ('admin', '123456');
INSERT INTO `zhmm` VALUES ('zff', '123');
