package shixun;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class zc extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			zc dialog = new zc();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public zc() {
		setResizable(false);
		setModal(true);
		setTitle("\u6CE8\u518C\u754C\u9762");
		setBounds(550, 200, 473, 466);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u6CE8\u518C");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 32));
		lblNewLabel.setBounds(184, 10, 72, 62);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u8F93\u5165\u7528\u6237\u540D\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(50, 92, 120, 51);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u8BF7\u8F93\u5165\u4F60\u7684\u5BC6\u7801\uFF1A");
		lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(10, 169, 162, 51);
		contentPanel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		lblNewLabel_1_2.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(70, 245, 100, 51);
		contentPanel.add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 18));
		textField.setBounds(178, 101, 222, 38);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("����", Font.PLAIN, 18));
		passwordField.setBounds(178, 178, 222, 38);
		contentPanel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setFont(new Font("����", Font.PLAIN, 18));
		passwordField_1.setBounds(178, 245, 222, 38);
		contentPanel.add(passwordField_1);
		
		JButton btnNewButton = new JButton("\u6CE8\u518C");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String zh = textField.getText();
				String mm = passwordField.getText();
				String mm1 = passwordField_1.getText();
				if(zh.equals("")|mm.equals("")|mm1.equals("")) {
					JOptionPane.showMessageDialog(contentPanel, "������������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}else {
				if(mm.equals(mm1)) {
					sjk sjk = new sjk();
					try {
						sjk.select("�û���", zh);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					if(sjk.r==true) {
						try {
							sjk.insert(zh, mm);
							JOptionPane.showMessageDialog(contentPanel, "��ϲ�㣬ע��ɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION); 
						} catch (ClassNotFoundException | SQLException e1) {
							// TODO �Զ����ɵ� catch ��
							e1.printStackTrace();
						}
						
					}else {
						JOptionPane.showMessageDialog(contentPanel, "���û����ѱ�ע�ᣬ����������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
					}
				}else {
					JOptionPane.showMessageDialog(contentPanel, "��������������벻һ��", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 19));
		btnNewButton.setBounds(108, 335, 97, 38);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				passwordField.setText("");
				passwordField_1.setText("");
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 19));
		btnNewButton_1.setBounds(255, 335, 97, 38);
		contentPanel.add(btnNewButton_1);
	}
}
