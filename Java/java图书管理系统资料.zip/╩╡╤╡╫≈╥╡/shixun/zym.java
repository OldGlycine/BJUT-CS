package shixun;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.ListSelectionModel;
import javax.swing.AbstractListModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class zym extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					zym frame = new zym();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public zym() throws ClassNotFoundException, SQLException {
		setResizable(false);
		setTitle("\u56FE\u4E66\u7BA1\u7406\u4E3B\u9875");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		table_1 = new JTable();
		table_1.setFont(new Font("����", Font.PLAIN, 15));
		table_1.setToolTipText("");
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		sjk sjk = new sjk();
		sjk.ts();
		table_1.setModel(new DefaultTableModel(
				sjk.tsj,	
			new String[] {
				"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
			}
			
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, Integer.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_1.setBounds(1, 27, 772, 218);
		
		contentPane.add(table_1);

		JScrollPane jsp = new JScrollPane(table_1); // ��Jtable���뵽���������
		jsp.setBounds(10, 192, 766, 269);//ָ����������λ�úʹ�С
		getContentPane().add(jsp);//���������Ϲ������
		
		textField = new JTextField();
		textField.setBounds(288, 47, 214, 34);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u641C\u7D22\u56FE\u4E66\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 22));
		lblNewLabel.setBounds(179, 47, 112, 34);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1_1 = new JButton("\u5220\u9664\u56FE\u4E66");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Object v = table_1.getValueAt(table_1.getSelectedRow(), 0);
					shixun.sjk sjk2 = new sjk();
					int s = JOptionPane.showConfirmDialog(contentPane,"�Ƿ�ȷ��ɾ����","ɾ����ʾ",1,2);
					if(s==0) {
						sjk2.delete(v);
						JOptionPane.showMessageDialog(contentPane, "ɾ���ɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION); 
					}else {
					}
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(contentPane, "��ѡ����ɾ��", "��ʾ",JOptionPane.DEFAULT_OPTION); 
				}
				
				
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				
				
			}
		});
		btnNewButton_1_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1_1.setBounds(330, 120, 122, 39);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("\u4FEE\u6539\u56FE\u4E66");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Object v = table_1.getValueAt(table_1.getSelectedRow(), 0);
					int v1=(int) v;
					String v2=""+v1;
					xgts dialog = new xgts(v2);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				}catch (Exception e1) {
					JOptionPane.showMessageDialog(contentPane, "��ѡ�����޸�", "��ʾ",JOptionPane.DEFAULT_OPTION); 
				}
				
				
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				
				
				
				
				
			}
		});
		btnNewButton_1_1_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1_1_1.setBounds(179, 120, 122, 39);
		contentPane.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_2 = new JButton("\u65B0\u589E\u56FE\u4E66");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				zjts dialog = new zjts();
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
			}
		});
		btnNewButton_1_1_2.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1_1_2.setBounds(28, 120, 122, 39);
		contentPane.add(btnNewButton_1_1_2);
		
		JButton btnNewButton_1_1_3 = new JButton("\u501F\u9605\u56FE\u4E66");
		btnNewButton_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jy dialog = new jy();
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
			}
		});
		btnNewButton_1_1_3.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1_1_3.setBounds(484, 120, 122, 39);
		contentPane.add(btnNewButton_1_1_3);
		
		JButton btnNewButton = new JButton("\u641C\u7D22");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ss = textField.getText();
				if(ss.equals("")) {
					JOptionPane.showMessageDialog(contentPane, "��������Ϊ��", "��ʾ",JOptionPane.DEFAULT_OPTION); 
				}else {
					sjk sjk = new sjk();
					try {
						sjk.tjcx(ss);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					table_1.setModel(new DefaultTableModel(
							sjk.ss,	
						new String[] {
							"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
						}
						
					) {
						Class[] columnTypes = new Class[] {
							Integer.class, String.class, String.class, Integer.class, Integer.class
						};
						public Class getColumnClass(int columnIndex) {
							return columnTypes[columnIndex];
						}
					});
				}
				
				
			}
		});
		btnNewButton.setBounds(513, 46, 97, 35);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1_1_2_1 = new JButton("\u8FD8\u4E66");
		btnNewButton_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hs dialog = null;
				try {
					dialog = new hs();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				
			}
		});
		btnNewButton_1_1_2_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1_1_2_1.setBounds(635, 120, 122, 39);
		contentPane.add(btnNewButton_1_1_2_1);
		
		JButton btnNewButton_1 = new JButton("\u663E\u793A\u6240\u6709\u56FE\u4E66");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sjk sjk = new sjk();
				try {
					sjk.ts();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table_1.setModel(new DefaultTableModel(
						sjk.tsj,	
					new String[] {
						"\u56FE\u4E66ID", "\u56FE\u4E66\u540D\u79F0", "\u56FE\u4E66\u4F5C\u8005", "\u56FE\u4E66\u603B\u6570\u91CF", "\u53EF\u501F\u6570\u91CF"
					}
					
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, String.class, Integer.class, Integer.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				
				
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 15));
		btnNewButton_1.setBounds(617, 475, 141, 39);
		contentPane.add(btnNewButton_1);
	}
}
