package shixun;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class hs extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			hs dialog = new hs();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public hs() throws ClassNotFoundException, SQLException {
		setTitle("\u8FD8\u4E66\u529F\u80FD");
		setResizable(false);
		setModal(true);
		setBounds(400, 200, 750, 405);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 0, 0);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);
		
		table = new JTable();
		sjk sjk = new sjk();
		sjk.jyxx2();
		table.setModel(new DefaultTableModel(
			sjk.jyxx,
			new String[] {
				"\u501F\u9605\u7F16\u53F7", "\u59D3\u540D", "\u501F\u9605\u603B\u5929\u6570", "\u501F\u9605\u56FE\u4E66\u540D\u79F0", "\u501F\u9605\u56FE\u4E66\u6570\u91CF", "\u501F\u9605\u65F6\u95F4", "\u8FD8\u4E66\u65F6\u95F4", "\u8FD8\u4E66\u72B6\u6001"
			}
		));
		table.setBounds(10, 141, 716, 160);
		contentPanel.add(table);
		JScrollPane jsp = new JScrollPane(table); // ��Jtable���뵽���������
		jsp.setBounds(10, 75, 716, 226);//ָ����������λ�úʹ�С
		getContentPane().add(jsp);//���������Ϲ������
		
		JLabel lblNewLabel = new JLabel("\u501F\u9605\u8BB0\u5F55");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 22));
		lblNewLabel.setBounds(320, 25, 90, 34);
		getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\u8FD8\u4E66");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Object v = table.getValueAt(table.getSelectedRow(), 0);
					sjk sjk = new sjk();
					int jysl = shixun.sjk.hsgn1(v);
					String jytsmc = shixun.sjk.hsgn11(v);
					int kjsl =shixun.sjk.hsgn2(jytsmc);
					shixun.sjk.hsgn3(kjsl,jysl,jytsmc);
					shixun.sjk.hsgn(v);
					JOptionPane.showMessageDialog(contentPanel, "����ɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION); 	
				}catch (Exception e1) {
					JOptionPane.showMessageDialog(contentPanel, "��ѡ�к��ٻ��飡", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}
				sjk sjk = new sjk();
				try {
					sjk.jyxx2();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				table.setModel(new DefaultTableModel(
					sjk.jyxx,
					new String[] {
						"\u501F\u9605\u7F16\u53F7", "\u59D3\u540D", "\u501F\u9605\u603B\u5929\u6570", "\u501F\u9605\u56FE\u4E66\u540D\u79F0", "\u501F\u9605\u56FE\u4E66\u6570\u91CF", "\u501F\u9605\u65F6\u95F4", "\u8FD8\u4E66\u65F6\u95F4", "\u8FD8\u4E66\u72B6\u6001"
					}
				));
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton.setBounds(496, 319, 84, 39);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1.setBounds(608, 319, 84, 39);
		getContentPane().add(btnNewButton_1);
		
	}
}
