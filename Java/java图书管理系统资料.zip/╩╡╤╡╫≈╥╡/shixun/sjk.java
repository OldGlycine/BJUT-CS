package shixun;
import java.sql.*;
import java.time.LocalDate;
public class sjk {
	private static final Exception Exception = null;
	public void insert(String zh,String mm) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="insert zhmm values('"+zh+"','"+mm+"')";
		PreparedStatement ps = conn.prepareStatement(sql);
		boolean re = ps.execute();
		conn.close();
		ps.close();
		//SQLIntegrityConstraintViolationException
	}
	boolean r=true;
	public void select(String cx,String sr) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select "+cx+" from zhmm";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		
		while(re.next()) {
			if(sr.equals(re.getString(cx))) {
				r=false;
				break;
			}
		}
		conn.close();
		ps.close();
	}
	boolean dl=false;
	public void selectyw(String zh,String mm) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from zhmm";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		while(re.next()) {
			re.getString("�û���");
			re.getString("����");
			if(re.getString("�û���").equals(zh)&re.getString("����").equals(mm)) {
				dl=true;
			}
		}
		conn.close();
		ps.close();
	}
	
	static Object [][] tsj;
	static int j=0;
	public static void ts1() throws ClassNotFoundException, SQLException{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from tsgj";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		while(re.next()) {
			j++;
		}
		conn.close();
		ps.close();
	}
	public static void ts() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from tsgj";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		ts1();
		int i=-1;
		tsj=new Object[j][];
		while(re.next()) {
			i++;
			int id=re.getInt("ͼ��ID");
			String mc=re.getString("ͼ������");
			String zz=re.getString("ͼ������");
			int zsl=re.getInt("ͼ��������");
			int kjsl=re.getInt("ͼ��ɽ�����");
			tsj[i]=new Object[] {id,mc,zz,zsl,kjsl};
		}
		j=0;
		conn.close();
		ps.close();
	}
	public void insert(int id,String mc,String zz,int sl,int kjsl) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="insert tsgj values("+id+",'"+mc+"',"+"'"+zz+"',"+sl+","+kjsl+")";
		PreparedStatement ps = conn.prepareStatement(sql);
		boolean re = ps.execute();
		conn.close();
		ps.close();
	}
	public void delete(Object id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="delete from tsgj where ͼ��ID="+id;
		PreparedStatement ps = conn.prepareStatement(sql);
		boolean re = ps.execute();
		conn.close();
		ps.close();
		
	}
	public void update(String mc,String zz,int zsl,int kjsl,int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="update tsgj set ͼ������='"+mc+"',ͼ������='"+zz+"',ͼ��������="+zsl+",ͼ��ɽ�����="+kjsl+" where ͼ��ID="+id;
		PreparedStatement ps = conn.prepareStatement(sql);
		boolean re = ps.execute();
		conn.close();
		ps.close();
		
	}
	static Object [][]ss;
	static int e=0;
	public static void tjcx1(String cx) throws ClassNotFoundException, SQLException{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from tsgj where ͼ������ like '%"+cx+"%'";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		while(re.next()) {
			e++;
		}
		conn.close();
		ps.close();
	}
	public void tjcx(String cx) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from tsgj where ͼ������ like '%"+cx+"%'";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		tjcx1(cx);
		ss=new Object [e][5];
		int e1=-1;
		while(re.next()) {
			e1++;
			ss[e1]=new Object[] {re.getInt("ͼ��ID"),re.getString("ͼ������"),re.getString("ͼ������"),re.getInt("ͼ��������"),re.getInt("ͼ��ɽ�����")};
			
		}
		e=0;
		conn.close();
		ps.close();
	}
	public static String jyts (int tsid,int tjsl) throws java.lang.Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql0="select ͼ��ɽ�����,ͼ������ from tsgj where ͼ��ID="+tsid;
		PreparedStatement ps0 = conn.prepareStatement(sql0);
		ResultSet re0 = ps0.executeQuery();
		int kjsl = 0;
		String tsmc="";
		while(re0.next()) {
			kjsl = re0.getInt("ͼ��ɽ�����");
			tsmc = re0.getString("ͼ������");
		}
		int kjsl1=kjsl-tjsl;
		if(kjsl1>=0) {
			String sql="update tsgj set ͼ��ɽ�����="+kjsl1+" where ͼ��ID="+tsid;
			PreparedStatement ps = conn.prepareStatement(sql);
			boolean re = ps.execute();
			conn.close();
			ps0.close();
			re0.close();
			ps.close();
			return tsmc;
		}else {
			throw Exception;
		}
	}
	public static void jyxx(String xm,int zts,String tsmc,int jssl,String jssj,String hssj) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="insert jyhs values(0"+",'"+xm+"',"+zts+",'"+tsmc+"',"+jssl+",'"+jssj+"','"+hssj+"')";
		PreparedStatement ps = conn.prepareStatement(sql);
		boolean re = ps.execute();
		conn.close();
		ps.close();
	}
	static Object [][] jyxx;
	static int j1=0;
	public static void jyxx1() throws ClassNotFoundException, SQLException{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from jyhs";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		while(re.next()) {
			j1++;
		}
		conn.close();
		ps.close();
	}
	public static void jyxx2() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql="select * from jyhs";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet re = ps.executeQuery();
		jyxx1();
		int i=-1;
		jyxx=new Object[j1][];
		
		String hszt="";
		LocalDate ldt = LocalDate.now();
		while(re.next()) {
			i++;
			int jybh = re.getInt("���ı��");
			String xm=re.getString("����");
			int jyzts=re.getInt("����������");
			String jytsmc=re.getString("����ͼ������");
			int jytssl=re.getInt("����ͼ������");
			String jysj = re.getString("����ʱ��");
			String hssj = re.getString("����ʱ��");
			LocalDate ldt1 =ldt.parse(hssj);
			boolean r = ldt1.isBefore(ldt);
			if(r==true) {
				 hszt="������";
			}else {
				 hszt="δ����";
			}
			jyxx[i]=new Object[] {jybh,xm,jyzts,jytsmc,jytssl,jysj,hssj,hszt};
		}
		j1=0;
		conn.close();
		ps.close();
	}
	public static void hsgn(Object bh) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		
		
		String sql0="delete from jyhs where ���ı��="+bh;
		PreparedStatement ps0 = conn.prepareStatement(sql0);
		boolean re0 = ps0.execute();
		
		
		

	}
	public static int hsgn1(Object bh) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql1="select ����ͼ������,����ͼ������ from jyhs where ���ı��="+bh;
		PreparedStatement ps1 = conn.prepareStatement(sql1);
		ResultSet re1 = ps1.executeQuery();
		int jysl = 0;
		String jytsmc = null;
		while(re1.next()) {
			jysl = re1.getInt("����ͼ������");
			jytsmc=re1.getString("����ͼ������");
		}	
		return jysl;
	}
	public static String hsgn11(Object bh) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql1="select ����ͼ������,����ͼ������ from jyhs where ���ı��="+bh;
		PreparedStatement ps1 = conn.prepareStatement(sql1);
		ResultSet re1 = ps1.executeQuery();
		int jysl = 0;
		String jytsmc = null;
		while(re1.next()) {
			jysl = re1.getInt("����ͼ������");
			jytsmc=re1.getString("����ͼ������");
		}
		return jytsmc;
	}
	public static int hsgn2(String jytsmc) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql3="select ͼ��ɽ����� from tsgj where ͼ������='"+jytsmc+"'";
		PreparedStatement ps3 = conn.prepareStatement(sql3);
		ResultSet re3 = ps3.executeQuery();
		int kjsl = 0;
		while(re3.next()) {
			kjsl = re3.getInt("ͼ��ɽ�����");
		}
		return kjsl;
	}
	public static void hsgn3(int kjsl,int jysl,String jytsmc) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		int kjsl1=kjsl+jysl;
		String sql2="update tsgj set ͼ��ɽ�����="+kjsl1+" where ͼ������='"+jytsmc+"'";
		PreparedStatement ps2 = conn.prepareStatement(sql2);
		boolean re2 = ps2.execute();
	}
	public static String [] xgts1(String tsid) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shixun","root","123456");
		String sql0="select * from tsgj where ͼ��ID="+tsid;
		PreparedStatement ps0 = conn.prepareStatement(sql0);
		ResultSet re0 = ps0.executeQuery();
		String [] sj=new String [4];
		while(re0.next()) {
			sj[0]=re0.getString("ͼ������");
			sj[1]=re0.getString("ͼ������");
			int zsl=re0.getInt("ͼ��������");
			int kjsl=re0.getInt("ͼ��ɽ�����");
			sj[2]=zsl+"";
			sj[3]=kjsl+"";
		}
		return sj;
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	}
}
