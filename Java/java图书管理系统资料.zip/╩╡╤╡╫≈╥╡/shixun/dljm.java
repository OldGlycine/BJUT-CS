package shixun;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class dljm extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					dljm frame = new dljm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public dljm() {
		setResizable(false);
		setTitle("\u56FE\u4E66\u7BA1\u7406\u767B\u5F55\u754C\u9762");
		setBackground(Color.CYAN);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 550, 335);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setForeground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 23));
		lblNewLabel.setBounds(76, 53, 121, 35);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(98, 112, 80, 35);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 18));
		textField.setBounds(174, 53, 241, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {
				String zh = textField.getText();
				String mm = passwordField.getText();
				if(zh.equals("")|mm.equals("")) {
					JOptionPane.showMessageDialog(contentPane, "������������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}else {
					sjk sjk = new sjk();
					try {
						sjk.select("�û���", zh);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					if(sjk.r==false) {
						try {
							sjk.selectyw(zh, mm);
						} catch (ClassNotFoundException | SQLException e1) {
							// TODO �Զ����ɵ� catch ��
							e1.printStackTrace();
						}
						if(sjk.dl==true) {
							JOptionPane.showMessageDialog(contentPane, "��¼�ɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION);
							setVisible(false);
							zym frame = null;
							try {
								frame = new zym();
							} catch (ClassNotFoundException | SQLException e1) {
								// TODO �Զ����ɵ� catch ��
								e1.printStackTrace();
							}
							frame.setVisible(true);
							
							
							
							
							
							
						}else {
							JOptionPane.showMessageDialog(contentPane, "�����������������", "��ʾ",JOptionPane.DEFAULT_OPTION);
						}
					}else {
						JOptionPane.showMessageDialog(contentPane, "���û���������", "��ʾ",JOptionPane.DEFAULT_OPTION);
					}
					
					
					
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(147, 193, 111, 45);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u6CE8\u518C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				zc zc = new zc();
				zc.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				zc.setVisible(true);		
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_1.setBounds(292, 193, 111, 45);
		contentPane.add(btnNewButton_1);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("����", Font.PLAIN, 18));
		passwordField.setBounds(174, 112, 241, 35);
		contentPane.add(passwordField);
	}
}
