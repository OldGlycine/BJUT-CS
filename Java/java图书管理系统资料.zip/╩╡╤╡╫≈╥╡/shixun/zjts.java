package shixun;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class zjts extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			zjts dialog = new zjts();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public zjts() {
		setModal(true);
		setResizable(false);
		setTitle("\u6DFB\u52A0\u56FE\u4E66");
		setBounds(550, 200, 441, 405);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u56FE\u4E66\u540D\u79F0\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel.setBounds(45, 66, 108, 32);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u56FE\u4E66\u4F5C\u8005\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(45, 119, 108, 32);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u56FE\u4E66\u603B\u6570\u91CF\uFF1A");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(24, 177, 129, 32);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u56FE\u4E66\u53EF\u501F\u6570\u91CF\uFF1A");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(10, 236, 129, 32);
		contentPanel.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(140, 70, 232, 27);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(140, 123, 232, 27);
		contentPanel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(140, 181, 232, 27);
		contentPanel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(140, 240, 232, 27);
		contentPanel.add(textField_3);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mc = textField.getText();
				String zz = textField_1.getText();
				String sl = textField_2.getText();
				String kjsl = textField_3.getText();
				String id = textField_4.getText();
				int sl1 = 0;
				int kjsl1 = 0;
				int id1 = 0;
				if(mc.equals("")|zz.equals("")|sl.equals("")|kjsl.equals("")|id.equals("")) {
					JOptionPane.showMessageDialog(contentPanel, "������������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}else {
					try {
					    sl1= Integer.parseInt(sl);
					   kjsl1 =Integer.parseInt(kjsl);
					   id1=Integer.parseInt(id);
					   sjk sjk = new sjk();
					   try {
						   if(sl1>=kjsl1) {
							   sjk.insert(id1, mc, zz, sl1, kjsl1);
								JOptionPane.showMessageDialog(contentPanel, "���ӳɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION);  
						   }else {
							   JOptionPane.showMessageDialog(contentPanel, "�ɽ��������ܴ���������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
						   }
						   
						} catch (ClassNotFoundException | SQLException e1) {
							JOptionPane.showMessageDialog(contentPanel, "ͼ��id������ͬ������������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
						}
					} catch (NumberFormatException e1) {
						JOptionPane.showMessageDialog(contentPanel, "������id��ʽ����ȷ", "��ʾ",JOptionPane.WARNING_MESSAGE); 
					}
					
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(76, 296, 98, 38);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_1.setBounds(239, 296, 98, 38);
		contentPanel.add(btnNewButton_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("\u56FE\u4E66id\uFF1A");
		lblNewLabel_3_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_3_1.setBounds(58, 10, 81, 32);
		contentPanel.add(lblNewLabel_3_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(140, 14, 232, 27);
		contentPanel.add(textField_4);
	}
}
