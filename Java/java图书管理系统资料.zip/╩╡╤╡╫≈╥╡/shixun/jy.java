package shixun;

import java.awt.BorderLayout;
import java.time.*;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;

public class jy extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			jy dialog = new jy();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public jy() {
		setTitle("\u56FE\u4E66\u501F\u9605");
		setResizable(false);
		setModal(true);
		setBounds(550, 200, 441, 405);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u501F\u9605\u4EBA\u59D3\u540D\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel.setBounds(34, 53, 109, 34);
		contentPanel.add(lblNewLabel);
		
		JLabel lblid_1 = new JLabel("\u501F\u9605\u56FE\u4E66ID\uFF1A");
		lblid_1.setFont(new Font("����", Font.PLAIN, 16));
		lblid_1.setBounds(34, 142, 103, 34);
		contentPanel.add(lblid_1);
		
		JLabel lblid_3 = new JLabel("\u501F\u9605\u56FE\u4E66\u6570\u91CF\uFF1A");
		lblid_3.setFont(new Font("����", Font.PLAIN, 16));
		lblid_3.setBounds(22, 186, 121, 34);
		contentPanel.add(lblid_3);
		
		JLabel lblNewLabel_1 = new JLabel("\u501F\u9605\u603B\u5929\u6570\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(34, 98, 109, 34);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u501F\u9605\u65F6\u95F4\uFF1A");
		lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(53, 227, 109, 34);
		contentPanel.add(lblNewLabel_1_1);
		
		textField = new JTextField();
		textField.setBounds(143, 235, 199, 21);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(143, 194, 199, 21);
		contentPanel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(143, 150, 199, 21);
		contentPanel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(143, 106, 199, 21);
		contentPanel.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(143, 61, 199, 21);
		contentPanel.add(textField_4);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u5F53\u524D\u65F6\u95F4");
		rdbtnNewRadioButton.setBounds(96, 267, 90, 23);
		contentPanel.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u81EA\u5B9A\u4E49\u65F6\u95F4");
		rdbtnNewRadioButton_1.setBounds(210, 267, 90, 23);
		contentPanel.add(rdbtnNewRadioButton_1);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnNewRadioButton);
		bg.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				LocalDate ldt = LocalDate.now();
				String ldt1 = ldt.toString();
				textField.setText(ldt1);
				
			}
		});
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				textField.setText("XXXX-XX-XX");
			}
		});
		
		JButton btnNewButton = new JButton("\u786E\u5B9A\u501F\u9605");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String xm = textField_4.getText();
				String zts = textField_3.getText();
				String tsid = textField_2.getText();
				String tssl = textField_1.getText();
				String jysj = textField.getText();
				LocalDate ldt = LocalDate.now();
				if(xm.equals("")|zts.equals("")|tsid.equals("")|tssl.equals("")|jysj.equals("")) {
					JOptionPane.showMessageDialog(contentPanel, "����д����", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}else {
					try {
						int tsid1 = Integer.parseInt(tsid);
						int zts1 = Integer.parseInt(zts);
						int tssl1 = Integer.parseInt(tssl);
						LocalDate jysj1 = null;
						try {
							jysj1 = ldt.parse(jysj);	
							String jysj2 = jysj1.toString();
							LocalDate hssj = jysj1.plusDays(zts1);
							String hssj1 = hssj.toString();
							sjk sjk = new sjk();
							
							try {
								String tsmc=sjk.jyts(tsid1, tssl1);
								sjk.jyxx(xm, zts1, tsmc, tssl1, jysj2, hssj1);
								JOptionPane.showMessageDialog(contentPanel, "����ɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION); 	
							}catch(Exception e2) {
								JOptionPane.showMessageDialog(contentPanel, "�ɽ�ͼ����������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
							}
						}catch(Exception e4) {
							JOptionPane.showMessageDialog(contentPanel, "ʱ���ʽ����ȷ", "��ʾ",JOptionPane.WARNING_MESSAGE); 
						}
						
						
						
					}catch(Exception e1) {
						JOptionPane.showMessageDialog(contentPanel, "������������ID��ʽ����ȷ", "��ʾ",JOptionPane.WARNING_MESSAGE); 
					}
				}
				
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton.setBounds(77, 307, 109, 34);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1.setBounds(222, 307, 109, 34);
		contentPanel.add(btnNewButton_1);
	}
}
