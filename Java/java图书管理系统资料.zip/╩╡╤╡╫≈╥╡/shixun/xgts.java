package shixun;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class xgts extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			xgts dialog = new xgts("");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public xgts(String tsid) {
		setResizable(false);
		setModal(true);
		setBounds(550, 200, 441, 405);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u4FEE\u6539\u56FE\u4E66\u540D\u79F0\u4E3A\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel.setBounds(24, 73, 160, 39);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u4FEE\u6539\u56FE\u4E66\u4F5C\u8005\u4E3A\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(24, 122, 160, 39);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u4FEE\u6539\u56FE\u4E66\u603B\u6570\u91CF\u4E3A\uFF1A");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(10, 171, 174, 39);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u4FEE\u6539\u53EF\u501F\u6570\u91CF\u4E3A\uFF1A");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(24, 220, 160, 39);
		contentPanel.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(165, 78, 182, 31);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(165, 127, 182, 31);
		contentPanel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(165, 176, 182, 31);
		contentPanel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(165, 225, 182, 31);
		contentPanel.add(textField_3);
		
		sjk sjk = new sjk();
		String[] sj =null;
		try {
			sj = sjk.xgts1(tsid);
		} catch (ClassNotFoundException | SQLException e3) {
			// TODO �Զ����ɵ� catch ��
			e3.printStackTrace();
		}
		textField.setText(sj[0]);
		textField_1.setText(sj[1]);
		textField_2.setText(sj[2]);
		textField_3.setText(sj[3]);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String mc = textField.getText();
				String zz = textField_1.getText();
				String zsl = textField_2.getText();
				String kjsl = textField_3.getText();
				if(mc.equals("")|zz.equals("")|zsl.equals("")|kjsl.equals("")) {
					JOptionPane.showMessageDialog(contentPanel, "������������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
				}else {
					try {
						int zsl1 = Integer.parseInt(zsl);
						int kjsl1 = Integer.parseInt(kjsl);
						int id = Integer.parseInt(tsid);
						try {
							if(zsl1>=kjsl1) {
								sjk.update(mc, zz, zsl1, kjsl1, id);
								JOptionPane.showMessageDialog(contentPanel, "�޸ĳɹ�", "��ʾ",JOptionPane.DEFAULT_OPTION); 
							}else {
								JOptionPane.showMessageDialog(contentPanel, "�ɽ��������ܴ���������", "��ʾ",JOptionPane.WARNING_MESSAGE); 
							}
						}catch(Exception e2) {
							JOptionPane.showMessageDialog(contentPanel, "����", "��ʾ",JOptionPane.WARNING_MESSAGE); 
						}	
					}catch(Exception e1){
						JOptionPane.showMessageDialog(contentPanel, "������ʽ����ȷ", "��ʾ",JOptionPane.WARNING_MESSAGE); 
					}
				}
				
				
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton.setBounds(82, 280, 102, 39);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 16));
		btnNewButton_1.setBounds(234, 280, 102, 39);
		contentPanel.add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("\u56FE\u4E66ID\u4E3A1\u7684\u4FEE\u6539");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_4.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(275, 10, 102, 46);
		contentPanel.add(lblNewLabel_4);
		lblNewLabel_4.setText(tsid);
		
		JLabel lblNewLabel_4_1 = new JLabel("\u6B63\u5728\u4FEE\u6539\u56FE\u4E66ID--");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_4_1.setBounds(100, 10, 182, 46);
		contentPanel.add(lblNewLabel_4_1);
	}
}
