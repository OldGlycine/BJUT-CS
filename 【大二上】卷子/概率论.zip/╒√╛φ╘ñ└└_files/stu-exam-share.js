function setStuAnswerOfSomeQues(quietSubmit){

	 var thisObj;
	if(quietSubmit){
	     thisObj = $(quietSubmit);
	}else{
	    thisObj = $('#submitTest');
	}
    var nowQuestionId= thisObj.find('input[name="questionId"]').val();
    if(!nowQuestionId){
        return;
    }

    var nowTypeQuestionId="type"+nowQuestionId;
    var questionType= thisObj.find("input[name='"+nowTypeQuestionId+"']").val();
    // 避免自动提交时简答题答案丢失
    if (questionType == 4 || questionType == 5 || questionType == 6 || questionType == 7 || questionType == 8 || questionType ==17 || questionType == 18) {
        var me = UE.getEditor('answer' + nowQuestionId);
        try{ 
           checkControlWordMax(me,questionType);
    	   me && me.sync();
        }catch(err){
           console.log(err);
        }
    }else if (questionType == 2 || questionType == 9 || questionType == 10) {
		var blankStr = "answerEditor" + nowQuestionId;
		var blankInputs = $("textarea[name^='" + blankStr + "']");
		blankInputs.length > 0 && blankInputs.each(function () {
			var blankEditorId = $(this).attr('id');
			if(blankEditorId){
			    var me = UE.getEditor(blankEditorId);
			    try{ 
			    	me && me.sync();
			    }catch(err){
			        console.log(err);
			    }
			}
		});
	}

    if(questionType==11){
        var answerPair=[];
        thisObj.find(".line_answer").find(".select").each(function(index){
            var checked=$(this).attr("value");
            var obj={};
            obj.name=(index+1);
            obj.content=(checked);
            answerPair.push(obj);
        });
        var answerStr=JSON.stringify(answerPair);
        thisObj.find("input[name='answer"+nowQuestionId+"']").val(answerStr);
    }else if(questionType == 13){
        var answerStr="";
        thisObj.find(".orderSelect").find(".select").each(function(){
            var checked=$(this).attr("value");
            answerStr=answerStr+checked;
        });
        thisObj.find("input[name='answer"+nowQuestionId+"']").val(answerStr);

    }else if(questionType == 14){//新完型填空
        var answerObj={};
        thisObj.find(".filling_answer").each(function(){
            var itemId=$(this).find("input[name='itemId']").val();
            var checked=$(this).find(".answerClass").val();
            if(checked == undefined){
                checked="";
            }
            var info={};
            info.answer=checked;
            answerObj[itemId]=info;
        });
        var answer=[];
        answer.push(answerObj);
        var answerStr=JSON.stringify(answer);
        thisObj.find("input[name='answer"+nowQuestionId+"']").val(answerStr);
    } else if (questionType == 15 || questionType == 16 || questionType == 19) {// 新阅读理解、综合题
        var answerObj={};
        thisObj.find("input[name='readCompreHension-childType']").each(function(index){
            var type=$(this).val();
            var itemId=$(this).next().val();
            var itemAnswer="";
            switch(parseInt(type)){
                case 0:
                case 3:{
                    itemAnswer= thisObj.find("input[name='answer" + nowQuestionId + itemId + "']").val();
                    break;
                }
                case 1:{
                    thisObj.find("input[name='answer" + nowQuestionId + itemId + "']").each(function() {
                        itemAnswer +=$(this).val();
                    });
                    var randomOptions = $("#randomOptions").val();
                    itemAnswer = randomOptions ? sortMultiAnswer(itemAnswer) : itemAnswer;
                    break;
                }
                case 2:{
                    var answerItem=[];
                    var blankNum=thisObj.find("input[name='" + nowQuestionId + itemId + "blankNum']").val();
                    for(var i=1;i<=blankNum;i++){
                        var answerEditorId="answerEditor" + nowQuestionId + itemId;
                        answerEditorId=answerEditorId + i;
                        var answerItemStr=UE.getEditor(answerEditorId).getContent();
                        var item={};
                        item.content=answerItemStr;
                        item.name=i.toString();
                        answerItem.push(item);
                    }
                    itemAnswer=answerItem;
                    break;
                }
                case 4:{
                    var answerEditorId = "answer" + nowQuestionId + itemId;
                    var answerEditorStr = UE.getEditor(answerEditorId).getContent();
                    itemAnswer=answerEditorStr;
                    break;
                }
                default: { }
            }

            var info={};
            info.type=parseInt(type);

            info.answer=(itemAnswer !== undefined ? itemAnswer: "");
            answerObj[itemId]=info;
        });
        var answer=[];
        answer.push(answerObj);
        var answerStr=JSON.stringify(answer);
        thisObj.find("input[name='answer"+nowQuestionId+"']").val(answerStr);
    } else if (questionType == 17) {
        var answer = [];
        var thisDiv = "#procedural-" + nowQuestionId;
        var currentEditor = UE.getEditor("answer"+nowQuestionId);
        var language= thisObj.find(thisDiv +" .languageSelect").attr("value");
        var richcode=currentEditor.getContent();
        var code=currentEditor.getPlainTxt(); code=UE.utils.html(code);
        var item={};
        item.language=parseInt(language);
        item.answer=richcode;
        item.answerTxt=code;
        answer[0]=item;
        var answerStr = JSON.stringify(answer);
        thisObj.find("input[name='answer" + nowQuestionId + "']").val(answerStr);
    }else if(questionType == 1){
        var randomOptions = $("#randomOptions").val();
        var multipleChoiceInput=thisObj.find("input[name='answers" + nowQuestionId + "']");
        var mulChoice=multipleChoiceInput.val();
        mulChoice = randomOptions ? sortMultiAnswer(mulChoice) : mulChoice;
        multipleChoiceInput.val(mulChoice);
    }
}

submitAjaxHandle = null ;

function submitForm(tempSave,quietSubmit,callBack) {
    if(tempSave){
        submitAjaxHandle != null && submitAjaxHandle.abort();
    }

    if(!quietSubmit){
        if(tempSave && window.submitOnce){
            return;
        } else if(tempSave){
            window.submitOnce = true;
        }
    }


    var timeOver = $("#timeOver").val();
    $("#tempSave").val(tempSave);

	//答题页面还是预览页面
	var answerMode = $('#answerMode').val() || 0;

    var submitStyle = 0;
    var submitTest = $("#submitTest");


    if(answerMode == 0){
    	setStuAnswerOfSomeQues();
    }else if(answerMode == 1 && quietSubmit){
        setStuAnswerOfSomeQues(quietSubmit);
    }

   var submitData = "";
    if(!tempSave && answerMode == 1){
	    $(".saveButtonClass").each(function () {
	        if($(this).is(':visible')) {
	           var dataid = $(this).attr("dataid");
	           var div = $("#sigleQuestionDiv_" + dataid);
	            setStuAnswerOfSomeQues(div);
	            var thisQuestionParam = answerModeParam(div);
	            if(typeof thisQuestionParam != "undefined") {
	                submitData += "&" + thisQuestionParam;
	            }
	        }
	    });
    }

    //最终提交
    if(!tempSave && timeOver == "false") {
    	var monitorforcesubmit = $('#monitorforcesubmit').val();
    	if(monitorforcesubmit > 0){
    		submitStyle = monitorforcesubmit;
    	}
        finalSubmitTest(tempSave,submitTest,submitStyle,submitData);
    } else if(!tempSave && timeOver == "true"){
    	/*
        var submitData = "";
        $(".saveButtonClass").each(function () {
            if($(this).is(':visible')) {
               var dataid = $(this).attr("dataid");
               var div = $("#sigleQuestionDiv_" + dataid);

                setStuAnswerOfSomeQues(div);
                var thisQuestionParam = answerModeParam(div);
                if(typeof thisQuestionParam != "undefined") {
                    submitData += "&" + thisQuestionParam;
                }
            }
        });
     */
        //时间到了自动提交
      if(timeOver == "true"){
            submitStyle = 4;
        }
        finalSubmitTest(tempSave,submitTest,submitStyle,submitData);
    } else {
        var pos = "";
        try{
            pos = getEnc();
            if(pos){
				pos = pos.replace(/\|/g,'%7C');
			}
    		var qid = quietSubmit && (quietSubmit.find('input[name="questionId"]').val() || '');
    		if(pos && qid){
    			pos = pos.replace('qid=&', 'qid=' + qid + '&');
    		}
        }catch(ex){}

        // 临时保存
        var param = getParamStr();
        param = param + "&pos=" + pos + '&version=1';
        var ajax_url = $("#saveUrl").val()  + param;
        var ajax_type = "post";
        var ajax_data = $("#submitTest").serialize();
        if(quietSubmit){
            //设置答案
            //setStuAnswerOfSomeQues(quietSubmit);
            var thisQuestionParam = answerModeParam(quietSubmit);
            if(thisQuestionParam){
                ajax_data = ajax_data + '&'  + thisQuestionParam;
            }
        }

        submitAjaxHandle = $.ajax({
            type : ajax_type,
            url : ajax_url,
            data : ajax_data,
            dataType : 'json',
            success : function(data) {
                var status = data.status;
                var msg = data.msg ;

                if(status == 'submitted' || status == 'forceSubmitted'){
                	closeMonitor();
                    removeTimeOverSubmitTimers();
                }

                if (status == "error" || status == 'submitted') {
                    window.submitOnce = false;
                    $.toast({type: 'failure', content: msg});
                    if(status == 'submitted'){
                    	 jumpExamLook();
                    }
                    return;
                }else if(status == 'forceSubmitted'){
                    window.submitOnce = false;
                    clearInterval(timer);
                    jumpExamLook();
                    return;
                }

                if(data.monitorparam){
                    data.monitorparam.answerMode = answerMode;
                }

                answerRecordLog && answerRecordLog(data.monitorparam);
                callBack && callBack(data.data);
                eachSubmitCheckRemainTime(data);
            },
            error : function(result){
                //提交失败
            	$.toast({type: 'failure', content: '提交失败'});
                window.submitOnce = false;
            },
            complete : function(){
                submitAjaxHandle = null;
            }
        });
    }
}


function finalSubmitTest(tempSave,formEle,submitStyle,submitData){

    function version(url){
        var re = /&version=(\d+)/;
        var version = 1;
        if (re.test(url)) {
            var arr = re.exec(url);
            version += parseInt(arr[1]);
            url = url.replace(re, '&version=' + version);
        } else {
            url = url + '&version=1';
        }
        return url;
    }

    var pos = "";
    try{
        pos = getEnc();
        if(pos){
			pos = pos.replace(/\|/g,'%7C');
		}
    }catch(ex){}

    var actionStr = version(formEle.attr('action'));
    formEle.attr('action', actionStr);
    var ajax_url  = actionStr + "&tempSave=" + tempSave + "&pos=" + pos;


    var data = formEle.serialize();
    if(typeof submitData != "undefined" && submitData != "") {
        data += submitData;
    }

    $.ajax({
        type : 'post',
        url : ajax_url,
        data : data,
        dataType : 'json',
        success : function(result) {
            var status = result.status;
            var msg = result.msg || I18N.subFailed;
            if(!status || status != 'success'){
                if(status == 'submitted' || status == 'forceSubmitted'){
                    removeTimeOverSubmitTimers();
                    closeMonitor();
                    $.toast({type: 'success', content: I18N.subSucc});
                    setTimeout(function() {
                        jumpExamLook();
                    }, 1000);
                }else{
                    $.toast({type: 'failure', content: msg});
                }
                $("#submitConfirmPop").fullFadeOut();
                return;
            }

            var data = {};
            data.submitStyle = submitStyle;
            finalSubmitExamLog(data);
removeTimeOverSubmitTimers();
            closeMonitor();

            if(submitStyle == 4) {
            	var consumeMinutes = result.consumeMinutes || 0;
 				if(consumeMinutes > 0){
 					$('.consumeMinutes').html(consumeMinutes);
 				}
               $("#timeOverSubmitConfirmPop .confirmClose").attr('onclick','timOverconfirmCloseCallBack();');
               $("#timeOverSubmitConfirmPop").fullFadeIn();
               return;
            }

            if(submitStyle == 5){
				exitForceSubmitTip($('#exitCount').val() || 0);
				return;
			}

			if(submitStyle == 8){
				switchScreenDurationLimitTip($('#switchScreenDurationLimit').val() || 0);
				return;
			}

            $.toast({type: 'success', content: I18N.subSucc});
            setTimeout(function() {
                jumpExamLook();
            }, 1000);

            $("#submitConfirmPop").fullFadeOut();
        },
        error : function(result){
            $.toast({type: 'failure', content: I18N.subFailed});

            $("#submitConfirmPop").fullFadeOut();
        }
    });
}


function getParamStr() {
    var testPaperId = $("#testPaperId").val();
    var testUserRelationId = $("#testUserRelationId").val();
    var courseId = $("#courseId").val();
    var classId = $("#classId").val();
    var cpi = $("#cpi").val();
    var tempSave=$("#tempSave").val();
    if(typeof(cpi)=="undefined"){
        cpi = 0;
    }
    return  "?classId=" + classId + "&courseId=" + courseId +"&cpi="+ cpi + "&testPaperId=" + testPaperId + "&testUserRelationId=" + testUserRelationId + "&tempSave=" + tempSave;
}


//首次进入考试日志
function entryExamLog(data){
    var snapshotMonitor = $('#snapshotMonitor').val();
    if(snapshotMonitor != 1){
        return;
    }
    var eventType = 0;
    pushExamMonitorLog(eventType,data);
}

//重新进入考试日志
function rentryExamLog(data){
    var snapshotMonitor = $('#snapshotMonitor').val();
    if(snapshotMonitor != 1){
        return;
    }
    var eventType = 1;
    pushExamMonitorLog(eventType,data);
}

//提交答案日志
function answerRecordLog(answerData){
    var snapshotMonitor = $('#snapshotMonitor').val();
    if(snapshotMonitor != 1){
        return;
    }
    if(!answerData){
        return;
    }
    
    var answerMode = $('#answerMode').val() || 0;
	if(answerMode == 1){
		var submitTime = answerData.submitTime || -1;
		if(submitTime > 0){
			$('#enterPageTime').val(submitTime);
		}
	}
    
    var eventType = 3;
    pushExamMonitorLog(eventType,answerData);
}

//最终提交考试日志
function finalSubmitExamLog(data){
    var snapshotMonitor = $('#snapshotMonitor').val();
    if(snapshotMonitor != 1){
        return;
    }
    var eventType = 2;
    pushExamMonitorLog(eventType,data);
}

//切屏日志
function switchScreenLog(data){
	var switchScreenControl = $('#switchScreenControl').val();
	if(switchScreenControl != 1){
		return;
	}
	if(!data){
		return;
	}
	var status = data.status;
	var eventType = 9;
    if(status == 1){
    	eventType = 10;
    }
	pushExamMonitorLog(eventType,data);
}

//监控抓拍日志
function snapshotMonitorLog(data){
	var snapshotMonitor = $('#snapshotMonitor').val();
	if(snapshotMonitor != 1){
		return;
	}
	  if(!data){
			return;
	  }
	 // alert(data.funconfig);
	  var funconfig = JSON.parse(data.funconfig || data.funConfig);
	  var answerId = $('#testUserRelationId').val();
	  var classId = $('#classId').val();
	  if(funconfig.answerId != answerId || funconfig.classId != classId){
		  return;
	  }
	  var similarity = data.similarity;
	  var status = true;
	  if(similarity < 50){
		  status = false;
	  }
	  data.status = status;
	  var eventType = 5;
	  pushExamMonitorLog(eventType,data);
}

//监控截屏日志
function clientSnapShotLog(data) {
	var snapshotMonitor = $('#snapshotMonitor').val();
	if (snapshotMonitor != 1) {
		return;
	}
	if (!data) {
		return;
	}
	var funconfig = JSON.parse(data.funconfig || data.funConfig);
	var answerId = $('#testUserRelationId').val();
	var classId = $('#classId').val();
	if (funconfig.answerId != answerId || funconfig.classId != classId) {
		return;
	}
	var eventType = 8;
	pushExamMonitorLog(eventType, data);
}


function pushExamMonitorLog(eventType,data,callBack) {
	try{
		if (typeof (data) != 'object') {
			data = {};
		}
		var url = '/keeper/api/receiveExamLogs?eventType=' + eventType;
		var currentFaceId = data.currentFaceId;

        if (eventType == 0 && ( typeof (currentFaceId) == "undefined" || currentFaceId == "")) {
            var _version=data.version;
            if (typeof (_version) != "undefined" && _version != -1) {
               // url = '/keeper/api/receiveExamLogs?currentFaceId=false&eventType=' + eventType;
                url = url + '&currentFaceId=false';
            }
        }
		
		var eventTime = new Date().getTime();
		var ip = "";
		if (eventType == 1) {
			eventTime = data.rentryExamTime;
		} else if (eventType == 2) {
			eventTime = data.finalSubmitTime;
		} else if (eventType == 3) {
			eventTime = data.submitTime;
		}
		//data.device = 0;
	
		var courseId = $('#courseId').val();
		var examRelationId = $('#testPaperId').val();
		var answerId = $('#testUserRelationId').val();
		var clazzId = $('#classId').val();
		var personId = $('#cpi').val();
		var log = {
				"courseId":courseId,
				"clazzId": clazzId,
				"personId":personId,
				"examRelationId":examRelationId,
				"answerId":answerId,
				"eventType":eventType,
				"ip":ip,
				"data":data
		};
	    var monitorEnc = $('#monitorEnc').val();
		$.ajax({
			type : 'post',
			dataType : 'json',
			url : url,
			data : {"log":JSON.stringify(log), "enc":monitorEnc},
			success : function(data) {
				callBack && callBack(data);
			}
		});
	}catch(err){}
}


function removeTimeOverSubmitTimers(){
    var overTimeSubmitTimers = window.OverTimeSubmitTimers;
    if(!overTimeSubmitTimers || overTimeSubmitTimers.length == 0){
        return ;
    }
    for(var i = 0 ; i < overTimeSubmitTimers.length; i++){
        var overTimeSubmitTimer = overTimeSubmitTimers[i];
        if(overTimeSubmitTimer){
            clearTimeout(overTimeSubmitTimer);
        }
    }
}

function timeOverSubmitTest() {
	submitForm(false, false);
	//时间用完提交后，默认重试两次
	if (!window.OverTimeSubmitTimers) {
		window.OverTimeSubmitTimers = [];
	}
	var overTimeSubmitTimers = window.OverTimeSubmitTimers;
	for (var i = 0; i < 2; i++) {
		var overTimer = setTimeout(function() {
			submitForm(false, false);
		}, (i + 1) * 5000);
		overTimeSubmitTimers.push(overTimer);
	}
}

function goExamList() {
    var qbanksystem =  $('#qbanksystem').val();
    var qbankbackurl =  $('#qbankbackurl').val();
    if(qbanksystem == 1 && qbankbackurl !== ''){
        qbankbackurl = decodeURIComponent(qbankbackurl);
        location.href = qbankbackurl;
        return;
    }

    var courseId = $("#courseId").val();
    var classId = $("#classId").val();
    var cpi = $("#cpi").val();
    var openc = $("#openc").val() || '';
    if(typeof(cpi)=="undefined"){
        cpi = 0;
    }
    var examsystem=$("#examsystem").val();
    location.href = "/exam-ans/mooc2/exam/exam-list?clazzid="+classId+"&courseid=" + courseId +"&cpi=" +cpi+ "&ut=s"  +
        "&examsystem=" + examsystem + "&openc=" + openc;
}


function sortMultiAnswer(answer) {
    if ( !answer || answer.trim().length == 0) {
        return "";
    }
    var answerArray = answer.trim().split('');
    var sortedAnswerArray = answerArray.sort();
    return sortedAnswerArray.join('');
}

function addEvaluationChoice(obj,selectNum) {
    var subObj = $(obj).find(".num_option_dx");
    var qid = $(subObj).attr("qid");
    
    if(!subObj.hasClass('check_answer_dx')){
    	var checkedNum = $('.choice' + qid + '.check_answer_dx').length;
    	selectNum = selectNum || 0;
    	if(selectNum > 0 && parseInt(checkedNum) >= parseInt(selectNum)){
    		  $.toast({type: 'notice', content: '最多选' + selectNum + '项'});
    		return false;
    	}
    }
    
    if($(subObj).hasClass("check_answer_dx")) {
        $(subObj).removeClass("check_answer_dx");
    } else {
        $(subObj).addClass("check_answer_dx");
    }

    var choiceContent = "";
    $(".choice" + qid).each(function(){
        if($(this).hasClass("check_answer_dx")){
            choiceContent = choiceContent + $(this).attr("data");
        }
    });
    $("#answer" + qid).val(choiceContent);
    return true;
}

function unhtml(input) {
    if(!input || input.length == 0) {
        return input;
    }
    var newInput=input.replace(/[&<">']/g, function (a, b) {
        return {
            '<':'&lt;',
            '&':'&amp;',
            '"':'&quot;',
            '>':'&gt;',
            "'":'&#39;'
        }[a];
    }) ;
    return newInput;
}

function timOverconfirmCloseCallBack(){
	jumpExamLook();
  	 $("#timeOverSubmitConfirmPop").fullFadeOut();
  }


function checkRemainTime(status){
	if(status == 'hidden'){
		 window.Leave_Exam_Page = new Date().getTime();
		 window.Leave_SingleQuesLimitTime = window.SingleQuesLimitTime || -1;
	}else if(status == 'visible'){
		window.Back_Exam_Page = new Date().getTime();
	}
	var leaveTime = window.Leave_Exam_Page || 0;
	var backTime = window.Back_Exam_Page || 0;
	var threshold = 1 * 60 * 1000;
	if(leaveTime > 0 && backTime > 0 && (backTime - leaveTime) >=  threshold){
		window.checkSingleQuesLimitTimeRemainTime && checkSingleQuesLimitTimeRemainTime();
		fireCheckRemainTime();
	}
}

function fireCheckRemainTime() {
	var formParams = $("#submitTest").serialize();
	$.ajax({
		type : 'post',
		url : '/exam-ans/mooc2/exam/check-remaintime',
		data : formParams,
		dataType : 'json',
		success : function(result) {
			delete window.Leave_Exam_Page;
			delete window.Back_Exam_Page;
			delete window.Leave_SingleQuesLimitTime;
			var status = result.status;
			var seconds = result.data;
			if (!status || !seconds || seconds < 1) {
				return;
			}
		    clearInterval(timers);
			maxtime = seconds;
			timers = setInterval("CountDown()",1000);
		}
	});
}

function validateAudioPlayTimes(frameElement) {
	var frameElementObj = $(frameElement);
	var mid = frameElementObj.attr('mid') || '';
	var objectid = frameElementObj.attr('data') || '';
	var playtimeslimit = frameElementObj.attr('playtimeslimit') || 0;
	if(mid == '' || objectid == '' || playtimeslimit  <= 0){
		return;
	}
	var quesId = $(frameElement).parents('.singleQuesId').attr('data') || '';
	var ajax_url = '/exam-ans/exam/test/audio-playtimes?qid=' + quesId  + '&mid=' + mid + '&objectid=' + objectid + '&times=' + playtimeslimit ;
	var ajax_type = "post"; 
	var ajax_data = $("#submitTest").serialize(); 
    submitAjaxHandle = $.ajax({
		type : ajax_type,
		url : ajax_url,
		data :ajax_data,
		dataType: "json",
		success : function(result){
			var status = result.status;
			if(status == 0){
				frameElement.contentWindow.stopAudioPlay();
				$('.audioLimitTimesTip span').text(playtimeslimit);
				$("#audioLimitTimesWin").fullFadeIn();

			}
		}
	});
}


//关闭考试监控项
function closeMonitor(){
	closeExamClientFaceMonitor();
	closeExamClientScreenCutting();
	closeExamClientScreenAndCapture();
	closeAttatchPreviewWinTab();
}

//关闭考试附件预览标签页
function closeAttatchPreviewWinTab(){
	if(window.cef && typeof (window.cef.ExamEnd) == 'function') {
		window.cef.ExamEnd();
	}
}

//调起客户端切屏协议
function openExamClientScreenCutting() {
	var pcclientSwitchout = $('#pcclientSwitchout').val();
	if (pcclientSwitchout == 1 && window.cef && typeof (window.cef.OpenScreenCutting) == 'function') {
		var switchScreenControl = $('#switchScreenControl').val();
		if (switchScreenControl == 1) {
			window.CLIENT_WEB_LIFECYCLE = function(data) {
				switchScreenLog(data);
			};
		}else{
			window.CLIENT_WEB_LIFECYCLE = function(data) {	};
		}
		var paramObj = {"is_open" : 1};
		window.cef.OpenScreenCutting(JSON.stringify(paramObj));
	}
}
//关闭客户端切屏协议
function closeExamClientScreenCutting() {
	if (window.cef && typeof (window.cef.OpenScreenCutting) == 'function') {
		var paramObj = {"is_open":0};
		window.cef.OpenScreenCutting(JSON.stringify(paramObj));
	}
}

//调起人脸抓拍协议
function openExamClientFaceMonitor(monitorOp, monitorStatus, funconfig) {
	var snapshotMonitor = $('#snapshotMonitor').val();
	if (snapshotMonitor == 1 && window.cef && typeof (window.cef.OpenFaceMonitor) == 'function') {
		window.CLIENT_FACE_COLLECTION = function(data){
			snapshotMonitorLog(data);
		};
		if (monitorOp > 0) {
			var paramObj = {"enable" : "1","internalTime" : monitorStatus,"funconfig" : funconfig};
			window.cef.OpenFaceMonitor && window.cef.OpenFaceMonitor(JSON.stringify(paramObj));
		} else if (monitorOp == 0) {
			closeExamClientFaceMonitor();
		}
	}
}
//关闭人脸监控
function closeExamClientFaceMonitor(){
	var snapshotMonitor = $('#snapshotMonitor').val();
	if(snapshotMonitor == 1 && window.cef && typeof (window.cef.OpenFaceMonitor) == 'function') {
		var paramObj = {"enable" : "0","internalTime" : "-1","funconfig" : ""};
		window.cef.OpenFaceMonitor && window.cef.OpenFaceMonitor(JSON.stringify(paramObj));
	}
}

//调起屏幕抓拍协议
function openExamClientScreenAndCapture(monitorOp, monitorStatus, funconfig) {
	//var screenshotTime = screenshotTime || 0;
	if (window.cef && typeof (window.cef.ScreenAndCapture) == 'function') {
		window.CLIENT_SNAP_SHOT = function(data){
			clientSnapShotLog(data);
		};
		if (monitorOp > 0) {
			var paramObj = {"enable" : 1,"internal" : monitorStatus,"funconfig" : funconfig};
			
			var snapshotIntervalMin = $('#snapshotIntervalMin').val() || 0;
			var snapshotIntervalMax = $('#snapshotIntervalMax').val() || 0;
			if(snapshotIntervalMin > 0 && snapshotIntervalMax > 0){
				paramObj.controlType = "1";
				paramObj.startCapture = "0";
				paramObj.random = {"randomMin":snapshotIntervalMin,"randomMax":snapshotIntervalMax};
			}	
			
			paramObj = supportCsUploadSwitch(paramObj);
			window.cef.ScreenAndCapture && window.cef.ScreenAndCapture(JSON.stringify(paramObj));
		} else if (monitorOp == 0) {
			closeExamClientScreenAndCapture();
		}
	}
}

//关闭屏幕抓拍
function closeExamClientScreenAndCapture(){
	if(window.cef && typeof (window.cef.ScreenAndCapture) == 'function') {
		var paramObj = {"enable" : 0,"internal" : 0,"funconfig" : ""};
		window.cef.ScreenAndCapture && window.cef.ScreenAndCapture(JSON.stringify(paramObj));
	}
}

//客户端退出考试答题页面
function examClientExitTest(qbankbackurl){
	closeMonitor();
	location.href = decodeURIComponent(qbankbackurl);
}



function editorPaste(o, html) {
	html.html = "";
	$.toast({type: 'failure', content: '只能录入不能粘贴!'});
	return false;
}

//function initEditor(width, height, editorId) {
//	var option = {
//		'initialFrameWidth' : 800,
//		'initialFrameHeight' : 150,
//		'pasteplain' : true
//	};
//	if (width && width > 0) {
//		option.initialFrameWidth = width;
//	}
//	if (height && height > 0) {
//		option.initialFrameHeight = height;
//	}
//	var editor = UE.getEditor(editorId, option);
//	var allowPaste = $('#allowPaste').val();
//	if (allowPaste == 0) {
//		editor.addListener('beforepaste', editorPaste);
//	}
//}

function replaceAttachPreviewPath() {
	$('a[href^="/exam-ans/ueditorupload/read"]').each(function() {
		var href = $(this).attr('href') || '';
		href = href.replace('/ueditorupload/read', '/examattach/read');
		$(this).attr('href', href);
	});
	window.ATTACH__NO_DOWNLOAD_PATH = '/exam-ans/examattach/read';
}

$(document).ready(function() {
	var allowDownloadAttachment  =	$("#allowDownloadAttachment").val();
	if (!(typeof allowDownloadAttachment != "undefined" && allowDownloadAttachment == "1")) {
		replaceAttachPreviewPath();
	}
	removeImageTitle();
});


function callback_exam(obj) {
	var winId = "multiTerminalWin";
	if ($('#' + winId).is(':visible')) {
		return;
	}
	var secondParam = false;
	var firstVisibleSaveBtn = $('.saveButtonClass:visible').first();
	if (firstVisibleSaveBtn.length == 1) {
		var dataId =firstVisibleSaveBtn.attr("dataid");
		secondParam = $("#sigleQuestionDiv_" + dataId);
	}
	
	var refreshPage = function(){
		var url = window.location.href;
		if (url && url.indexOf('tag=1') != -1) {
			url = url.replace('tag=1', 'tag=0');
			window.location.href = url;
		}else{
			window.location.reload(true);
		}
	};

	var confirmFunction = function() {
		submitForm(true, secondParam, function() {
			refreshPage();
		});
	};
	var cancelFunction = function() {
		submitForm(true, secondParam, function() {
			if($('#isChaoxingExamPc').val() == 'true'){
				  closeMonitor();
				  location.href = examNotesUrl();

			}else{
				window.close();
				closeMonitor();
				refreshPage();
			}
	   });
   };
		
	var confirmBtn = $('#' + winId).find('.confirmClose');
	var cancelBtn = $('#' + winId).find('.cancel')
	confirmBtn.off('click');
	cancelBtn.off('click');
	confirmBtn.on('click', confirmFunction);
	cancelBtn.on('click', cancelFunction);
	var message = obj.mes;
	$('#' + winId).find('.popWord').html(message);
	$("#" + winId).fullFadeIn();
	frozenTestStatus();
}


function examNotesUrl(){
	var courseId = $('#courseId').val();
	var examRelationId = $('#testPaperId').val();
	var clazzId = $('#classId').val();
	var  url = '/exam-ans/exam/test/examcode/examnotes?examId=' + examRelationId + '&courseId=' + courseId + '&classId=' + clazzId;
    var qbanksystem =  $('#qbanksystem').val();
    var qbankbackurl =  $('#qbankbackurl').val();
    if(qbanksystem == 1 && qbankbackurl != ''){
    	url = url +  '&qbanksystem=' + qbanksystem + '&qbankbackurl=' + qbankbackurl;
    }
    return url;
}

function frozenTestStatus(){
	clearInterval(timers);
}


function jumpExamLook(){
	
	var courseId = $('#courseId').val();
	var examRelationId = $('#testPaperId').val();
	var testUserRelationId = $('#testUserRelationId').val();
	var clazzId = $('#classId').val();
	var cpi = $('#cpi').val();
	
    var url ='/exam-ans/exam/test/look?courseId=' + courseId + '&classId=' + clazzId + '&examId=' +  examRelationId + '&examAnswerId='+ testUserRelationId + '&cpi=' + cpi;
	 var qbanksystem =  $('#qbanksystem').val();
	 var qbankbackurl =  $('#qbankbackurl').val();
	 if(qbanksystem == 1 && qbankbackurl != ''){
		 url += '&qbanksystem=' +  qbanksystem  +  '&qbankbackurl=' +  qbankbackurl; 
	 }
	 
	 var webSnapshotMonitor = $('#webSnapshotMonitor').val();

	 if(webSnapshotMonitor == 1){
		 parent.window.location.href = url;
	 }else{
		 window.location.href = url;
	 }
}


//网页考试客户端监听网络变化
$(window).load(function() {
	var userAgent = navigator.userAgent || '';
	var webExamClientKey = 'chaoxingExamPc';
	if(userAgent && userAgent.indexOf(webExamClientKey) != -1){
		$(window).on('online', function() {
			$.toast({type : 'success',content : '网络状态已连接'});
		});
		$(window).on('offline', function() {
			$.toast({type : '', content : '网络异常，请检查网络连接'});
		});
	}
});


function removeImageTitle(){
	$('.TiMu img').each(function(){
		$(this).removeAttr('title');
	});
}

function feedback(){

	var content = $("#feedbackReason").val()
	var clazzId = $("#classId").val()
	var examId = $("#testPaperId").val()
	var examCreaterId = $("#examCreateUserId").val()
	var enc = $("#feedbackEnc").val()
	if (typeof content == "undefined" || content == "") {
		$.toast({type : 'notice', content : I18N.feedbackEmpty});
		return;
	}
	if (content.length > 500) {
		content = content.substring(0, 500);
	}

	$.ajax({
		type : "post",
		url : "/keeper/feedback/addtopic",
		data : {
			content:content,
			clazzId:clazzId,
			examId:examId,
			examCreaterId:examCreaterId,
			content:content,
			enc:enc
		},
		success : function(data) {
			if (data.status) {
				$.toast({type : 'success', content : I18N.feedbackSuccess});
				$('#rebackPop').fullFadeOut();
			} else {
				$.toast({type : 'notice', content : data.msg});
			}
		}
	});
}


function supportCsUploadSwitch(options) {
	if (!options) {
		options = {};
	}
	try {
		var uploadParams = {};
		var uploadConfig = {};
		var uploadUrl = $("#workExamUploadUrl").val();
		var uploadCrcUrl = $("#workExamUploadCrcUrl").val();
		if (typeof uploadUrl != "undefined" && uploadUrl != "") {
			uploadConfig.uploadUrl = uploadUrl;
		}
		if (typeof uploadCrcUrl != "undefined" && uploadCrcUrl != "") {
			uploadConfig.uploadCrcUrl = uploadCrcUrl;
		}
		var uploadtype = 'examkeeper';
		if (typeof uploadUrl != "undefined" && uploadUrl != "") {
			uploadConfig.uploadUrl += "?uploadtype=" + uploadtype;
			options.uploadConfig = uploadConfig;
		} else {
			uploadParams.uploadtype = uploadtype;
			options.uploadParams = uploadParams;
		}
	} catch (err) {}
	return options;
}


$(document).ready(function(event) {
	try {
		var examWaterMark = $('#ExamWaterMark').val();
		if(!examWaterMark){
			return;
		}
		setTimeout(function(){
			watermark({"watermark_txt" : examWaterMark});
		},5);
	} catch (err) {}
});


function exitCount(status,callBack,backTime,outTime) {
	var exitbtime = backTime || 0;
	var exitotime = outTime || 0;
	var exitdtime =  parseInt((exitbtime - exitotime) / 1000);
	if(exitdtime > 0){
		$('#exitdtime').val(exitdtime);
	}else{
		$('#exitdtime').val(0);
	}
	var answerId = $("#testUserRelationId").val();
	var classId = $("#classId").val();
	var et = $('#exitdtime').val();
	var url = '/exam-ans/mooc2/exam/exit-count?classId=' + classId + "&testUserRelationId=" + answerId + "&status=" + status + "&et=" + et;
	var data = $("#submitTest").serialize(); // 表单数据
	$.ajax({
		type : 'post',
		url : url,
		data : data,
		dataType : 'json',
		success : function(data) {
            if(data && data.status){
            	callBack && callBack(data);
            }
		}
	});
}

function exitCountAndExitTip(status,data){
	 var  callBack = function(data){
		var submitStyle = data.submitStyle || 0;
		var exitTimes = data.exitTimes || 0;
		if(submitStyle && (submitStyle == 5 || submitStyle == 8)){
			$('#switchScreenPop').fullFadeOut();
			finalSubmitExamLog({"submitStyle" : submitStyle});
			if(submitStyle == 5){
				exitForceSubmitTip(exitTimes);
			}else if(submitStyle == 8){
				switchScreenDurationLimitTip($('#switchScreenDurationLimit').val() || 0);
			}

		}
	};
	exitCount(status,callBack,data.backTime,data.outTime);
}

function exitForceSubmitTip(exitTimes) {
	var seconds = 5;
	var popWord = $('#exitTimesSubmitPop .popWord').attr('data');
	popWord = popWord.replace('{1}',exitTimes);
	$('#exitTimesSubmitPop .popWord').html(popWord);
	
	var confirmCloseBtn = $('#exitTimesSubmitPop .confirmClose');
	var confirmClose = confirmCloseBtn.attr('data');
	confirmCloseBtn.html(confirmClose  +'（' + seconds + "s" + '）');
	
	var okCallBack =  function(){
		jumpExamLook();
		$('#exitTimesSubmitPop').fullFadeOut();
	};
    
	confirmCloseBtn.off('click');
	confirmCloseBtn.on('click',okCallBack);
	 $('#exitTimesSubmitPop').fullFadeIn();
	var timer = setInterval(function() {
		seconds--;
		$('#exitTimesSubmitPop .confirmClose').html(confirmClose +'（' + seconds + "s" + '）');
		if (seconds == 1) {
			clearInterval(timer);
			okCallBack();
		}
	}, 1000);
}

function switchScreenDurationLimitTip(durationLimit) {
	var seconds = 5;
	var popWord = $('#exitDurationSubmitPop .popWord').attr('data');
	popWord = popWord.replace('{1}',durationLimit);
	$('#exitDurationSubmitPop .popWord').html(popWord);
	
	var confirmCloseBtn = $('#exitDurationSubmitPop .confirmClose');
	var confirmClose = confirmCloseBtn.attr('data');
	confirmCloseBtn.html(confirmClose  +'（' + seconds + "s" + '）');
	
	var okCallBack =  function(){
		jumpExamLook();
		$('#exitDurationSubmitPop').fullFadeOut();
	};
	
	confirmCloseBtn.off('click');
	confirmCloseBtn.on('click',okCallBack);
	$('#exitDurationSubmitPop').fullFadeIn();
	var timer = setInterval(function() {
		seconds--;
		$('#exitDurationSubmitPop .confirmClose').html(confirmClose +'（' + seconds + "s" + '）');
		if (seconds == 1) {
			clearInterval(timer);
			okCallBack();
		}
	}, 1000);
}


 function isPromiseAsyncAwaitSupport() {
    	var func;
    	try {
    		if(typeof(Promise) != 'function'){
    			return false;
    		}
    		eval("func = async function(){};");
    	} catch (e) {
    		return false;
    	}
	    return Object.getPrototypeOf(func).constructor != null;
}


function webSnapshotMonitorAction(){
	  var isChaoxingExamPc = $('#isChaoxingExamPc').val() || '';
	  if(isChaoxingExamPc == 'true'){
		  return;
	  }
	  var webSnapshotMonitor = $('#webSnapshotMonitor').val() || 0;
	  if(webSnapshotMonitor != 1){
		  return;
	  }
	  if(!isPromiseAsyncAwaitSupport()){
		  $.toast({type : 'failure', content : '当前浏览器版本过低（不支持监考），请升级当前浏览器到最新版本或切换使用其他浏览器',time: 5000});
	      return;
       }

	  $.ajax({
		  type: 'GET', 
		  url: '/exam-ans/mooc2/js/exam/webmonitor.js?v=2022-0921-1606',
		  dataType: 'script',
		  cache: true,
		  success:  function() {
			    webMonitorStart();
	      }
	 });

	  /*
      $.getScript('/exam-ans/mooc2/js/exam/webmonitor.js', function() {
    	   webMonitorStart();
      });
      */
}

$(function(){
	webSnapshotMonitorAction();
})


function eachSubmitCheckRemainTime(data){
	if(!data){
		return;
	}
	var realRemainTime = data.realRemainTime;
	if(!realRemainTime || realRemainTime <= 0){
		return;
	}
	var threshold = 30 ;
	if(maxtime >= 0 && realRemainTime > 0 && Math.abs(maxtime - realRemainTime) >= threshold){
		clearInterval(timers);
		maxtime = realRemainTime;
		timers = setInterval("CountDown()", 1000);
	}
}

function wordMinMaxNumOption(_ueOption,_wordMinNum,_wordMaxNum){   
	var ueOption = _ueOption;
	if(!ueOption){
		ueOption = {'pasteplain':true};
	}
	var wordCount = false;
	var wordMinNum = _wordMinNum || 0;
	var wordMaxNum = _wordMaxNum || 0;
	 if(wordMinNum && wordMinNum > 0){
		ueOption.minimumWords = wordMinNum;
		wordCount = true;
	}
	if(wordMaxNum && wordMaxNum > 0){
		ueOption.maximumWords = wordMaxNum;
		wordCount = true;
	}
	if(wordCount){
	   if(wordMaxNum == 0){
		   ueOption.maximumWords = 0;
	   }
	   ueOption.wordCount = true;
	   ueOption.wordCountTimer = false;
	}
	return ueOption;
}

function checkControlWordMax(ueditor,questionType){
	if(!ueditor){
    	return;
    }
	if(questionType == 4 || questionType == 5 || questionType == 6 || questionType == 7 || questionType == 8 || questionType == 18 ){
        var textarea = $(ueditor.iframe).parents('.subEditor').find('textarea');
        var wordMaxNum = textarea.attr('wordmaxnum') || 0;
        if(wordMaxNum > 0){
        	controlWordMax(ueditor,wordMaxNum);
	   }
 	}
}

function initWordMaxMiddleContainer(){
	if($('#wordMaxMiddleContainer').length == 1){
		return;
	}
	var ele = '<div style="display:none;"><textarea  id="wordMaxMiddleContainer"></textarea></div>';
	$('body').append(ele);
	UE.getEditor('wordMaxMiddleContainer',{'pasteplain':true});
}

function controlWordMax(ueditor,wordMaxNum) {
	    if(!ueditor || !wordMaxNum || wordMaxNum <= 0){
	    	return;
	    }
        var words = ueditor.pureWord();
        var wordsCount = words.length;
        if (wordsCount > wordMaxNum) {
            var keyWord = words[wordMaxNum - 1];
            var match = [];
            var richContent = ueditor.getContent();
            var index = richContent.indexOf(keyWord);
            var cycleSafeLimit = 6000;
            while (index !== -1 && match.length <= cycleSafeLimit) {
                match.push(index + keyWord.length);
                index = richContent.indexOf(keyWord, index + keyWord.length);
            }
            if(match.length > 0){
	            for (var i = match.length - 1; i >= 0; i--) {
	                var subRichContent = richContent.substring(0, match[i]);
	                var middleContainer = UE.getEditor('wordMaxMiddleContainer');
	                middleContainer.setContent(subRichContent);
	                if (middleContainer.pureWordCount() <= wordMaxNum) {
	                    break;
	                }
	            }
            }else{
            	var plainTxt = ueditor.getPlainTxt();
				if(plainTxt){
					plainTxt = plainTxt.replace(/<[^>]+>/g,'');
			    }
            	var plainTxtWords = plainTxt.split(' ');
            	var subRichContent = plainTxtWords.slice(0, wordMaxNum).join(' ');
            	var middleContainer = UE.getEditor('wordMaxMiddleContainer');
                middleContainer.setContent(subRichContent);
            }
            if(middleContainer.getContent() != ueditor.getContent()){
              ueditor.setContent(middleContainer.getContent());
              ueditor.focus(true);
            }
        }
}


$(document).ready(function(){if(window.eHook && typeof(window.changeTime) == 'function'){window.changeTime = function(){};}});

var secondDeviceClickFlag = false;
function secondDeviceLiveAction(showType) {
    if (secondDeviceClickFlag) {
        return;
    }
    secondDeviceClickFlag = true;
    setTimeout(function () {
        secondDeviceClickFlag = false;
    }, 2000);
    var clazzId = $("#classId").val();
    var examId = $("#testPaperId").val();
    var personId = $('#cpi').val();
    var bigRefreshCode = '/exam-ans/css/phone/images/big-refreshcode.png';
    var retryRereshClass = 'retryReresh';
    var successProcess = function(data, showType) {
        var studentCode = data.studentCode;
        var loginCode = data.loginCode;
        var liveUrlQrCode = data.liveUrlQrCode;
        if (showType == 0) {
            var context = '<p>' + I18N.liveAccount + '：' + studentCode + '</p><p>' + I18N.passwordI18N + '：' + loginCode + '</p>'
            $(".liveBox").html("");
            $(".liveBox").html(context);
        } else {
            $("#loginName").html(studentCode);
            $("#password").html(loginCode);
            $("#ewmUrl").attr("src", liveUrlQrCode);
            $("#ewmUrl").attr("onclick", "");
            $("#showLoginInfo").fullFadeIn();
        }
    }

    var failProcess = function(showType) {
        if (showType == 1) {
            $('#ewmUrl').attr('src', bigRefreshCode);
            $('#ewmUrl').addClass(retryRereshClass);
            $("#showLoginInfo").fullFadeIn();
        } else {
            $.toast({type: 'failure', content: '操作失败'});
        }
    }
    var url = '/keeper/live/another-device/info?clazzId=' + clazzId + '&examId=' + examId + '&personId=' + personId;
    $.ajax({
        url: url,
        type: 'get',
        dataType: 'json',
        success: function (result) {
            if (result.status) {
                successProcess(result.data, showType);
            } else {
                failProcess(showType);
                $.toast({
                    type: 'failure',
                    content: result.msg
                });
            }
        },
        error: function () {
            failProcess(showType);
        }
    });
}

function rereshSecondDeviceQRCode() {
    if($('#ewmUrl').hasClass('retryReresh')){
        secondDeviceLiveAction(1);
        return;
    }
}

